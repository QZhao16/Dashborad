# Part 1,relative_dispersion
#### function: compute a Earlier warming signal (e.g. relative_dispersion) in Vest R package
relative_dispersions <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "relative_dispersion" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    relative_dispersion <-
      function(x) {
        sd(x) / sd(diff(x)[-1])
      }  # end of the "relative_dispersion" function
    
    Ews <- c(Ews, relative_dispersion(inciddences[(j-window_size+1):j]) )   #compute the "relative_dispersion" for each rolling window
  }
  return(Ews)
}



# Part 2,max_lyapunov_exp
#### function: compute a Earlier warming signal (e.g. max_lyapunov_exp) in Vest R package
max_lyapunov_exps <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "max_lyapunov_exp" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    max_lyapunov_exp <-
      function(x) {
        library(nonlinearTseries) 
        len <- length(x)
        Reduce(max,
               nonlinearTseries::divergence(
                 nonlinearTseries::maxLyapunov(
                   time.series = x,
                   min.embedding.dim = 1,
                   max.embedding.dim = len,
                   radius = ceiling(sqrt(len)),
                   do.plot = FALSE
                 )
               ))
      }  # end of the "max_lyapunov_exp" function
    
    Ews <- c(Ews, max_lyapunov_exp(inciddences[(j-window_size+1):j]) )   #compute the "max_lyapunov_exp" for each rolling window
  }
  return(Ews)
}

# Part 3, Hurst exponent
#### function: compute a Earlier warming signal (e.g. Hurst exponent) in Vest R package
#dataset=new_data$Incidence
#window_size=8
#j=37
#x=inciddences[(j-window_size+1):j]
#window_indices=37

Hurst_exponents <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Hurst exponent" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    HURST <-function(x, nmoments=1) {
      
       if (all(x==0)){HURST_final=NA}
       if (length(unique(x))==1){HURST_final=NA}
       if (!(all(x==0)) && length(unique(x))!=1 ){
       library(Rwave)
        cwtwnoise <- DOG(x, 10, 5, nmoments, plot = FALSE)
        mcwtwnoise <- Mod(cwtwnoise)
        mcwtwnoise <- mcwtwnoise * mcwtwnoise
        wspwnoise <- tfmean(mcwtwnoise, plot = FALSE)
        
        HURST_final<-hurst.est(wspwnoise, 1:5, 5, plot = FALSE)[[2]]
       }#if
        return(HURST_final)
      }  # end of the "Hurst exponent" function
    
    Ews <- c(Ews, HURST(inciddences[(j-window_size+1):j]) )   #compute the "Hurst exponent" for each rolling window
  }
  return(Ews)
}


# Part 4, time series acceleration
#### function: compute a Earlier warming signal (e.g. time series acceleration) in Vest R package
time_series_acceleration <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "time series acceleration" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    accelaration <-
      function(x) {
        #require(TTR)
        
        if (length(x) > 10) {
          n <- 5
        }
        else {
          n <- 3
        }
        
        if (length(x) < 4) {
          return(
            c(avg_accl=NA,
              sdev_accl=NA)
          )
        }
        
        ts_sma <- TTR::SMA(x, n = n)
        ts_ema <- TTR::EMA(x, n = n)
        
        ts_sma <- ts_sma[!is.na(ts_sma)]
        ts_ema <- ts_ema[!is.na(ts_ema)]
        
        sema <- ts_sma / ts_ema
        sema <- sema[!(is.infinite(sema) | is.na(sema))]
        
        accl_ <- ts_sma / ts_ema
        
        c(avg_accl=mean(accl_),
          sdev_accl=stats::sd(accl_))
      }  # end of the "accelaration" function
    
    Ews <- c(Ews, accelaration(inciddences[(j-window_size+1):j])[1] )   #compute the "time series acceleration" for each rolling window
  }
  return(Ews)
}



# Part 5, Slope
#### function: compute a Earlier warming signal (e.g. Slope) in Vest R package
Slopes <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Slope" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    slope <-
      function(x) {
        time_x <- seq_along(x)
        lmfit <- lm(x ~ time_x)
        
        lmfit$coefficients[[2]]
      }  # end of the "Slope" function
    
    Ews <- c(Ews, slope(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 6, Daubechies DWT (i.e. discrete wavelet transform (DWT) developed by Ingrid Daubechies)
#### function: compute a Earlier warming signal (e.g. Daubechies DWT) in Vest R package
Daubechies_DWT <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    #library(Rssa)
    #library(chronosphere)
    #library(remotes)
    #library(wavelets)
    
    #install.packages("wmtsa", repos="http://R-Forge.R-project.org")
    library(wmtsa)

    # load the "Daubechies DWT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    dauDWTenergy <-
      function(x, lvl=4) {
        
        r <-tryCatch(wavDWT(x, wavelet="s8", n.levels=lvl),
                   error = function(e) {
                     NA
                   })
        
        if (is.na(r)) {
          dummy_ed <- rep(NA, times=lvl)
          names(dummy_ed) <- paste0("Ed",1:lvl)
          
          return(c(E_ra5=NA,dummy_ed))
        }
        
        dwt_result <- r$data
        
        E_a5 <- reconstruct(r) # reconstruct(r) is to re-achive the r
        E_a5 <- norm(t(E_a5))
        
        E_dk <- sapply(dwt_result[1:lvl], function(x) norm(t(x)))
        names(E_dk) <- paste0("Ed", 1:length(E_dk))
        
        E_T <- E_a5 + sum(E_dk)
        
        E_ra5 <- E_a5 / E_T
        
        E_rdk <- E_dk / E_T
        
        c(E_ra5=E_ra5,E_rdk)
      }  # end of the "Daubechies DWT" function
    
    Ews <- c(Ews, dauDWTenergy(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 7, no outliers
#### function: compute a Earlier warming signal (e.g. no outliers) in Vest R package
#dataset=new_data$Incidence
#x=dataset
#window_size=10
#steps=1
#window_indices=10

no_outliers <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "no outliers" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    nout2 <-
      function(x) {
        detr <- diff(x)
        
        sum(abs(detr) > 1.5*IQR(detr))
      }  # end of the "no outliers" function
    
    Ews <- c(Ews, nout2(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 8, Step change
#### function: compute a Earlier warming signal (e.g. Step change) in Vest R package
#inciddences=new_data$Incidence
#window_size=10
#j=10
#x=inciddences[(j-window_size+1):j]
#window_indices=10

Step_changes <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Step change" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    step_change <-function(x) {
        lko <- x[length(x)]
        rv <- x[-length(x)]
        
        has_s_c <- abs(lko - mean(rv)) > 2*sd(rv)
        
        as.integer(has_s_c)
      }  # end of the "Step change" function
    
    Ews <- c(Ews, step_change(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 9, N peaks
#### function: compute a Earlier warming signal (e.g. N peaks) in Vest R package
N_peaks <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "N peaks" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    npeaks <-
      function(x) {
        nincr <- sum(diff(sign(diff(x)))==-2)
        ndecr <- sum(diff(sign(diff(x)))==2)
        l <- length(x)
        
        c(ndecr=ndecr/l, nincr=nincr/l)
      }  # end of the "N peaks" function
    
    Ews <- c(Ews, npeaks(inciddences[(j-window_size+1):j])[1] )   
  }
  return(Ews)
}


# Part 10, Turning Points
#### function: compute a Earlier warming signal (e.g. Turning Points) in Vest R package
Turning_Points <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Turning Points" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    tpoints <-
      function(x) {
        dx <- diff(x)
        sum(sign(dx))
      }  # end of the "Turning Points" function
    
    Ews <- c(Ews, tpoints(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 11, Convert FFT
#### function: compute a Earlier warming signal (e.g. Convert FFT) in Vest R package
Convert_FFT <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Convert FFT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    convert.fft <-
      function(cs) {
        sample.rate = 1
        
        cs <- cs / length(cs) # normalize
        
        distance.center <- function(c)
          signif(Mod(c),        4)
        angle           <- function(c)
          signif(180 * Arg(c) / pi, 3)
        
        df <- data.frame(
          cycle    = 0:(length(cs) - 1),
          freq     = 0:(length(cs) - 1) * sample.rate / length(cs),
          strength = sapply(cs, distance.center),
          delay    = sapply(cs, angle)
        )
        df
      }  # end of the "Convert FFT" function
    
    Ews <- c(Ews, convert.fft(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 12, FFT AMP (Fast Fourier Transform amplitude), FT amplitude provides a clear picture of what seasonal frequencies are present in your signal and their relative strengths
#### function: compute a Earlier warming signal (e.g. FFT AMP) in Vest R package
FFT_AMP <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "FFT AMP" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    fft_strength <-
      function(x) {
        dx <- diff(x)
        library(vest)
        fft_data <- convert.fft(stats::fft(dx))
        
        mean(fft_data[,"strength"])
      } # end of the "FFT AMP" function
    
    Ews <- c(Ews, fft_strength(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 13, Poincare variability
#### function: compute a Earlier warming signal (e.g. Poincare variability) in Vest R package
poincare_variabilitys <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Poincare variability" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    poincare_variability <-
      function(x) {
        sd1 = sd(diff(x))/sqrt(2)
        sd2 = sqrt(2 * var(x) - sd1^2)
        
        c(sd1=sd1,sd2=sd2)
      } # end of the "Poincare variability" function
    
    Ews <- c(Ews, poincare_variability(inciddences[(j-window_size+1):j])[1] )   
  }
  return(Ews)
}





# Part 14, wavelet filtered
#### function: compute a Earlier warming signal (e.g. Poincare variability) in Vest R package
#Turning_Points(new_data$Incidence,leng_window,1)
#date=new_data$start
#dataset=new_data$Incidence
#window_size=5
#j=5

library(WaveletComp)
wavelet_filterings <- function (dataset=original_data, date=original_date, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset
  date=date
  
  my.date <- as.POSIXct(date, format = "%Y-%m-%d")
  if (is.na(my.date[1])) {my.date <- as.POSIXct(date, format = "%Y/%m/%d")}
  #
  my.data <- data.frame(date = my.date, x = inciddences)
  

  # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Poincare variability" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    wavelet_filtering <-
      function(x) {
        my.wt <- analyze.wavelet(my.data, "x", 
                                 loess.span = 0, 
                                 dt = 1/7, dj = 1/7, 
                                 lowerPeriod = 1/4, 
                                 make.pval = TRUE, n.sim = 10,
                                 date.format = "%Y-%m-%d", date.tz = "")
        
        
        
        j1 <- 1  # adjust these based on your scale selection
        j2 <- length(my.wt$power[, 1])
        T <- length(data)
        delta_t <- 1  # Time step, adjust as per your data's time interval
        lambda <- 1  # This needs to be defined based on the wavelet used and your specific scaling
        # Calculation
        W2 <- pi * T * delta_t / lambda * sum(my.wt$power[j1:j2,] / my.wt$period[j1:j2])
        
        return( c(W2) )
      } # end of the "Poincare variability" function
    
    Ews <- c(Ews, wavelet_filtering(inciddences[(j-window_size+1):j])[1] )   
  }
  return(Ews)
}




# Part 15, wavelet reddening
#### function: compute a Earlier warming signal (e.g. Poincare variability) in Vest R package
#Turning_Points(new_data$Incidence,leng_window,1)
#date=new_data$start
#dataset=new_data$Incidence
#window_size=5
#j=5

library(WaveletComp)
wavelet_reddenings <- function (dataset=original_data, date=original_date, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset
  date=date
  
  my.date <- as.POSIXct(date, format = "%Y-%m-%d")
  if (is.na(my.date[1])) {my.date <- as.POSIXct(date, format = "%Y/%m/%d")}
  #
  my.data <- data.frame(date = my.date, x = inciddences)
  
  
  # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Poincare variability" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    wavelet_reddening <-
      function(x) {
        my.wt <- analyze.wavelet(my.data, "x", 
                                 loess.span = 0, 
                                 dt = 1/7, dj = 1/7, 
                                 lowerPeriod = 1/4, 
                                 make.pval = TRUE, n.sim = 10,
                                 date.format = "%Y-%m-%d", date.tz = "")
        
        
        # Extract the wavelet power spectrum
        power_spectrum <- abs(my.wt$W)^2
        # Sum power spectrum across time to find j_max (maximum level of decomposition)
        total_power <- colSums(power_spectrum)
        # Normalize by the maximum power at each scale
        normalized_power <- power_spectrum / max(total_power)
        # Calculate the cumulative normalized power across scales
        cumulative_power <- apply(normalized_power, 2, cumsum)
        # Determine the median scale at each time point
        s_median <- apply(cumulative_power, 2, function(x) min(which(x > 0.5))) 
        W2<-min(s_median[is.finite(s_median)],na.rm = T) #femove inf and NA
        return( c(W2) )
      } # end of the "Poincare variability" function
    
    Ews <- c(Ews, wavelet_reddening(inciddences[(j-window_size+1):j])[1] )   
  }
  return(Ews)
}

