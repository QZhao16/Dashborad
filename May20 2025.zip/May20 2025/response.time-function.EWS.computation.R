
#
coxph_EWs_do_response<-function (new_datas,leng_window,Yes_No){
  new_data=new_datas  
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  
  if (situations=='No'){final_results_2=NULL}else{
    if (proportion_0>=0.90 ){final_results_2=NULL}else{
      #common EWs + P value
      leng_window=leng_window # difine the length of time window
      number=100 # define the number of surrogates
      final_results_2=rbind(#c(coxph_response_time(AR1(new_data$Incidence,leng_window,1),new_data),"AR1"),
                            #c(coxph_response_time(AR2(new_data$Incidence,leng_window,1),new_data),"AR2"),
                            #c(coxph_response_time(AR3(new_data$Incidence,leng_window,1),new_data),"AR3"),
                            c(coxph_response_time(SD(new_data$Incidence,leng_window,1),new_data),"SD"),
                            c(coxph_response_time(Skewness(new_data$Incidence,leng_window,1),new_data),"Skewness"),
                            c(coxph_response_time(Kurtosis(new_data$Incidence,leng_window,1),new_data),"Kurtosis"),
                            c(coxph_response_time(CV(new_data$Incidence,leng_window,1),new_data),"CV"),
                            c(coxph_response_time(first_differenced_variance(new_data$Incidence,leng_window,1),new_data),"first_differenced_variance"),
                            c(coxph_response_time(Autocovariance(new_data$Incidence,leng_window,1),new_data),"Autocovariance"),
                            c(coxph_response_time(index_of_dispersion(new_data$Incidence,leng_window,1),new_data),"index_of_dispersion"),
                            c(coxph_response_time(density_ratio(new_data$Incidence,leng_window,1),new_data),"density_ratio"),
                            
                            #c(coxph_response_time(Max_eigen(new_data$Incidence,leng_window,1),new_data),"Max_eigen"),
                            
                            #vest function
                            #c(coxph_response_time(relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))],new_data),"relative_dispersions"),
                            c(coxph_response_time(Hurst_exponents(new_data$Incidence,leng_window,1),new_data),"Hurst_exponents")
                            #c(coxph_response_time(time_series_acceleration(new_data$Incidence,leng_window,1),new_data),"time_series_acceleration"),
                            #c(coxph_response_time(no_outliers(new_data$Incidence,leng_window,1),new_data),"no_outliers"),
                                 #c(coxph_response_time(N_peaks(new_data$Incidence,leng_window,1),new_data),"N_peaks"),
                                 #c(coxph_response_time(Turning_Points(new_data$Incidence,leng_window,1),new_data),"Turning_Points"),
                            
                                ##c(coxph_response_time(wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_filtering"),
                                ##c(coxph_response_time(wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_reddening")
      )
      
      final_results_2=as.data.frame(final_results_2)
      
      final_results_2$length_time_series=nrow(subs_data)
      final_results_2$i_number=i_number
      final_results_2$the_total=replicate_number
      final_results_2$time_length=length(new_data$Incidence)
      final_results_2$frequency=The_frequece
      final_results_2$disease=the_diseases
      final_results_2$country_region=the_countrys
      final_results_2$outbreaks=situations
      final_results_2$number=1
      final_results_2$leng_window=leng_window
      final_results_2$Yes_No=Yes_No
      colnames(final_results_2)=c("Responses_time","EWs",
                                  "length_time_series",
                                  "ith_number","the_total",
                                  "time_length","frequency",
                                  "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
      final_results_2
      
      return(final_results_2)
    } # if (proportion_0>=0.90 )
  }#if (situations=='No')
  
} # function EWs_do




#new_data<-new_datas
#functions<-Max_eigen(new_data$Incidence,leng_window,1)
#functions<-AR1(new_data$Incidence,leng_window,1)

# response time after the sep7_2024
coxph_response_time<-function(functions,new_data){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  function_valu=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  function_values<-function_valu[!is.na(function_valu)]# no NA
  ii=1
  if (length(function_values)>0 ){
  for (ii in 1:(length(function_values)-1)) {
    
    datas<-NULL
    datas<-data.frame(time0=as.numeric(new_data$date)[1:length(function_values)], time=1:length(function_values),status=c(rep(0,length(function_values)-1),1),predictor=function_values )
    datas[ii,"status"]<-1
    #P_tau_values<-summary( coxph(Surv(time0,status) ~ scale(predictor), data = datas) )$coefficients[5]
    P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "lognormal"))$table[2,4]# [9] # longest lead time
    trend_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "lognormal"))$table[2,1]# [9] # longest lead time
    #P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "exponential"))$table[2,4]# middle lead time
    #P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "weibull"))$table[2,4]# shortest lead time
    if(!any(is.na(P_tau_values))){
      
                      #if (P_tau_values<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=length(function_valu)-length(function_values)} } else {response_times=length(function_valu)-length(function_values)}
      if (P_tau_values<0.05 & trend_values>0) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
      #if (P_tau_values<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
    response_timess<-c(response_timess,response_times)
  }#for
  
  #if( is.na(response_timess[length(response_timess)] ) ) {response_timess[length(response_timess)]=0} # if the end is NA, incidating there is no response time
  if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} #if all is NA, incidating there is no response time
  
  repsonses_time_final<-response_timess[!is.na(response_timess)][1] } else {repsonses_time_final<-0}#max(response_timess, na.rm=T) # the responses time is the first non-NA value
  return(repsonses_time_final)
}


##
# new_data<-subs_data_32
# leng_window<-4
# first_differenced_variance(new_data$Incidence,leng_window,1)
# SD(new_data$Incidence,leng_window,1)

CCA_response_time<-function(functions,new_data){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  function_valu=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  function_values<-function_valu[!is.na(function_valu)]# no NA
  ii=1
  if (length(function_values)>0 ){
    for (ii in 1:(length(function_values)-1)) {
      
      datas<-NULL
      datas<-data.frame(time0=as.numeric(new_data$date)[1:length(function_values)], time=1:length(function_values),status=c(rep(0,length(function_values)-1),1),predictor=function_values )
      datas[ii,"status"]<-1
      #P_tau_values<-summary( coxph(Surv(time0,status) ~ scale(predictor), data = datas) )$coefficients[5]
      P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "lognormal"))$table[2,4]# [9] # longest lead time
      #P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "exponential"))$table[2,4]# middle lead time
      #P_tau_values<-summary(survreg(Surv(time, status) ~ predictor, data = datas, dist = "weibull"))$table[2,4]# shortest lead time
      if(!any(is.na(P_tau_values))){
        
        #if (P_tau_values<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=length(function_valu)-length(function_values)} } else {response_times=length(function_valu)-length(function_values)}
        if (P_tau_values<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
      response_timess<-c(response_timess,response_times)
    }#for
    
    #if( is.na(response_timess[length(response_timess)] ) ) {response_timess[length(response_timess)]=0} # if the end is NA, incidating there is no response time
    if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} #if all is NA, incidating there is no response time
    
    repsonses_time_final<-response_timess[!is.na(response_timess)][1] } else {repsonses_time_final<-0}#max(response_timess, na.rm=T) # the responses time is the first non-NA value
  return(repsonses_time_final)
}

# leng_window=2
# cca_result<-cancor(1:7, cbind(CV(subs_data_31$Incidence,leng_window,1),SD(subs_data_31$Incidence,leng_window,1)) )
# n <- 7#nrow(as.data.frame(df[, c("X")]))       # sample size
# p <- 1#ncol(as.data.frame(df[, c("X")]) )       # number of X variables
# q <- 2#ncol(as.data.frame(df[, c("Z1", "Z2", "Z3")]) )      # number of Y variables
# p_vals <- p.asym(cca_result$cor, n, p, q, tstat = "Wilks")
# #GAM
# library(mgcv)
# 
# y=1:7
# x1<-CV(subs_data_31$Incidence,leng_window,1)
# x2<-SD(subs_data_31$Incidence,leng_window,1)
# datas<-data.frame(time=y,status=c(0,0,0,0,0,0,1),y=y,x1=x1,x2=x2)
# gam_model <- gam(y ~ s(x1)+
#                      s(x2),data = datas, family = gaussian())
# summary(gam_model)
# #
# 
# P_tau_values<-summary(survreg(Surv(time, status) ~ x2, data = datas, dist = "lognormal"))$table[2,4]
# 
# 
# 
# set.seed(123)
# mydata <- data.frame(
#   x1 = runif(100),
#   x2 = rnorm(100),
#   x3 = runif(100, 0, 10),
#   y = 1:100
# )
# 
# # Fit GAM
# gam_model <- gam(y ~ s(x1) + s(x2) + s(x3), data = mydata, method = "REML")
# summary(gam_model)
# library(gratia)
# draw(gam_model)



#functions=SD(new_data$Incidence,leng_window,1)
# response time before the June11_2024
response_time_before<-function(functions){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  number=100 # define the number of surrogates
  
  function_values=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  ii=5
  for (ii in 1:length(function_values)) {
  
  P_tau_values<-Ebisuzaki_method(number,function_values[1:ii]) # checking 1:length(function_values) for where starting significant
  if(!any(is.na(P_tau_values))){
    
    if (P_tau_values[1]>0 && P_tau_values[2]<0.05) {response_times<-length(function_values)-ii} else {response_times=NA} } else {response_times=NA}
    #if (P_tau_values[2]<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
  
  response_timess<-c(response_timess,response_times)
  }#for
  
  #if( is.na(response_timess[length(response_timess)] ) ) {response_timess[length(response_timess)]=0} # if the end is NA, incidating there is no response time
  if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} #if all is NA, incidating there is no response time
  
  repsonses_time_final<-response_timess[!is.na(response_timess)][1] #max(response_timess, na.rm=T) # the responses time is the first non-NA value
  return(repsonses_time_final)
}


# response time after the sep7_2024
response_time<-function(functions,new_data){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  number=100 # define the number of surrogates
  
  function_values=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  ii=5
  for (ii in 1:length(function_values)) {
    
    P_tau_values<-Ebisuzaki_method(number,function_values[1:ii]) # checking 1:length(function_values) for where starting significant
    if(!any(is.na(P_tau_values))){
      
      if (P_tau_values[1]>0 && P_tau_values[2]<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
      #if (P_tau_values[2]<0.05)                       {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
    
    response_timess<-c(response_timess,response_times)
  }#for
  
  #if( is.na(response_timess[length(response_timess)] ) ) {response_timess[length(response_timess)]=0} # if the end is NA, incidating there is no response time
  if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} #if all is NA, incidating there is no response time
  
  repsonses_time_final<-response_timess[!is.na(response_timess)][1] #max(response_timess, na.rm=T) # the responses time is the first non-NA value
  return(repsonses_time_final)
}


# response time after the sep7_2024
response_time_backup<-function(functions,new_data){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  number=100 # define the number of surrogates
  
  function_values=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  ii=5
  for (ii in 1:length(function_values)) {
    
    P_tau_values<-Ebisuzaki_method(number,function_values[1:ii]) # checking 1:length(function_values) for where starting significant
    if(!any(is.na(P_tau_values))){
      
      #if (P_tau_values[1]>0 && P_tau_values[2]<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
      if (P_tau_values[2]<0.05) {response_times<-length(new_data$Incidence)-ii} else {response_times=NA} } else {response_times=NA}
    
    response_timess<-c(response_timess,response_times)
  }#for
  
  #if( is.na(response_timess[length(response_timess)] ) ) {response_timess[length(response_timess)]=0} # if the end is NA, incidating there is no response time
  if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} #if all is NA, incidating there is no response time
  
  repsonses_time_final<-response_timess[!is.na(response_timess)][1] #max(response_timess, na.rm=T) # the responses time is the first non-NA value
  return(repsonses_time_final)
}



#functions=Hurst_exponents(new_data$Incidence,leng_window,1)
#response time on June11_2024
response_time_June11_2024<-function(functions){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  number=100 # define the number of surrogates
  
  function_values=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  ii=5
  for (ii in 1:length(function_values)) {
    
    P_tau_values<-Ebisuzaki_method(number,function_values[1:ii]) # checking 1:length(function_values) for where starting significant
    #if(!any(is.na(P_tau_values))){
      if(!(is.na(P_tau_values[1])) &  !(is.na(P_tau_values[2])) ){      
      if (P_tau_values[1]>0 && P_tau_values[2]<=0.05) {response_times<-length(function_values)-ii} else {response_times=NA} } else {response_times=NA}
    
    response_timess<-c(response_timess,response_times)
  }#for
  
  if (all(is.na(response_timess))){ repsonses_time_final=NA } else {repsonses_time_final<-response_timess[!is.na(response_timess)][1]} # the responses time is the first non-NA value }
  
  return(repsonses_time_final)
}


# response time sep-6 2024
#functions<-SD(new_data$Incidence,leng_window,1)
#leng_window=5
#original_datass=c(1:10,NA)
#cor(1:11,original_datass, method="kendall")
#ii=9
response_time_<-function(functions){ # computed as distance from the significant-point to outbreak point Re=1
  response_timess<-NULL
  
  function_values=functions # return values form the functions, e.g. function_values=AR1(new_datas$Incidence,leng_window,1); AR3(new_datas$Incidence,leng_window,1) 
  
  # Define a function that performs the correlation test
  perform_cor_test <- function(ii) {
    if (ii == 1) { return(cbind(NA,NA,NA))}  # Return NA for ii == 1 because cor.test cannot be performed with a single data point
    
  # Use tryCatch to handle any potential errors during the test
    tau_result <- tryCatch({
      cor.test(1:ii, functions[1:ii], method = "kendall",use = "complete.obs")$estimate
    }, error = function(e) {
      NA  # Return NA if an error occurs (e.g., not enough data points)
    })
    
    # Use tryCatch to handle any potential errors during the test
    p_result <- tryCatch({
      cor.test(1:ii, functions[1:ii], method = "kendall",use = "complete.obs")$p.value
    }, error = function(e) {
      NA  # Return NA if an error occurs (e.g., not enough data points)
    })
    
    # Use tryCatch to handle any potential errors during the test
    runing_value<-( functions[ii]- mean(functions[1:ii],na.rm=T) )/sd(functions[1:ii],na.rm=T)
    runing_mean <- tryCatch({
      ifelse(runing_value>mean(functions[1:ii],na.rm=T)+2*sd(functions[1:ii],na.rm=T),0,1) #significant as 0, non-signifcant as 1
    }, error = function(e) {
      NA  # Return NA if an error occurs (e.g., not enough data points)
    })
    
    
    return(cbind(tau_result,p_result,runing_mean))
  }
  
  # Use sapply to apply this function over the range 
  P_tau_values <- sapply(1:length(function_values), perform_cor_test)
  j=2
  
  for (j in 1:ncol(P_tau_values)){
    if(!any(is.na(P_tau_values[2:3,j]))){
    #if (P_tau_values[1,j]>0 && P_tau_values[2,j]<0.05) {response_times<-length(function_values)-j} else {response_times=NA} } else {response_times=NA}
    if (P_tau_values[2,j]<0.05 && P_tau_values[3,j]<0.05 ) {response_times<-length(function_values)-j} else {response_times=NA} } else {response_times=NA}
   response_timess<-c(response_timess,response_times) }
  
  if(  all(is.na(response_timess)) ) {response_timess[length(response_timess)]=0} # if all is NA, incidating there is no response time
  
  repsonses_time_final<-response_timess[!is.na(response_timess)][1] # the responses time is the first non-NA value
  return(repsonses_time_final)
}


#functions=no_outliers(new_data$Incidence,leng_window,1)
#response_time(Turning_Points(new_data$Incidence,leng_window,1))
##function
#EWs_do(new_datas)
#new_datas


# responses time alone
# before 2024 June
EWs_do_response_<-function (new_datas,leng_window,Yes_No){
  new_data=new_datas  
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  
  if (situations=='No'){final_results_2=NULL}else{
  if (proportion_0>=0.90 ){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(response_time(AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(response_time(AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(response_time(AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(response_time(SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(response_time(Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(response_time(Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(response_time(CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(response_time(first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(response_time(Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(response_time(index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(response_time(density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          #c(response_time(Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(response_time(relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(response_time(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(response_time(Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(response_time(time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          c(response_time(Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(response_time(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(response_time(no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          c(response_time(Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(response_time(N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(response_time(Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          c(response_time(FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          c(response_time(poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )

    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$length_time_series=nrow(subs_data)
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$leng_window=leng_window
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Responses_time","EWs",
                                "length_time_series",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
  } # if (proportion_0>=0.90 )
  }#if (situations=='No')
  
} # function EWs_do




# after 2024 sep-7
EWs_do_response<-function (new_datas,leng_window,Yes_No){
  new_data=new_datas  
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  
  if (situations=='No'){final_results_2=NULL}else{
    if (proportion_0>=0.90 ){final_results_2=NULL}else{
      #common EWs + P value
      leng_window=leng_window # difine the length of time window
      number=100 # define the number of surrogates
      final_results_2=rbind(c(response_time(AR1(new_data$Incidence,leng_window,1),new_data),"AR1"),
                            c(response_time(AR2(new_data$Incidence,leng_window,1),new_data),"AR2"),
                            c(response_time(AR3(new_data$Incidence,leng_window,1),new_data),"AR3"),
                            c(response_time(SD(new_data$Incidence,leng_window,1),new_data),"SD"),
                            c(response_time(Skewness(new_data$Incidence,leng_window,1),new_data),"Skewness"),
                            c(response_time(Kurtosis(new_data$Incidence,leng_window,1),new_data),"Kurtosis"),
                            c(response_time(CV(new_data$Incidence,leng_window,1),new_data),"CV"),
                            c(response_time(first_differenced_variance(new_data$Incidence,leng_window,1),new_data),"first_differenced_variance"),
                            c(response_time(Autocovariance(new_data$Incidence,leng_window,1),new_data),"Autocovariance"),
                            c(response_time(index_of_dispersion(new_data$Incidence,leng_window,1),new_data),"index_of_dispersion"),
                            c(response_time(density_ratio(new_data$Incidence,leng_window,1),new_data),"density_ratio"),
                            
                            c(response_time(Max_eigen(new_data$Incidence,leng_window,1),new_data),"Max_eigen"),
                            
                            #vest function
                            c(response_time(relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))],new_data),"relative_dispersions"),
                            #c(response_time(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                            c(response_time(Hurst_exponents(new_data$Incidence,leng_window,1),new_data),"Hurst_exponents"),
                            c(response_time(time_series_acceleration(new_data$Incidence,leng_window,1),new_data),"time_series_acceleration"),
                            #c(response_time(Slopes(new_data$Incidence,leng_window,1),new_data),"Slopes"),
                            #c(response_time(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                            c(response_time(no_outliers(new_data$Incidence,leng_window,1),new_data),"no_outliers"),
                            #c(response_time(Step_changes(new_data$Incidence,leng_window,1),new_data),"Step_changes"),
                            c(response_time(N_peaks(new_data$Incidence,leng_window,1),new_data),"N_peaks"),
                            c(response_time(Turning_Points(new_data$Incidence,leng_window,1),new_data),"Turning_Points"),
                            #c(response_time(FFT_AMP(new_data$Incidence,leng_window,1),new_data),"FFT_AMP"),
                            #c(response_time(poincare_variabilitys(new_data$Incidence,leng_window,1),new_data),"poincare_variabilitys")
                            c(response_time(wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_filtering"),
                            c(response_time(wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_reddening")
                            )
      
      final_results_2=as.data.frame(final_results_2)
      
      final_results_2$length_time_series=nrow(subs_data)
      final_results_2$i_number=i_number
      final_results_2$the_total=replicate_number
      final_results_2$time_length=length(new_data$Incidence)
      final_results_2$frequency=The_frequece
      final_results_2$disease=the_diseases
      final_results_2$country_region=the_countrys
      final_results_2$outbreaks=situations
      final_results_2$number=1
      final_results_2$leng_window=leng_window
      final_results_2$Yes_No=Yes_No
      colnames(final_results_2)=c("Responses_time","EWs",
                                  "length_time_series",
                                  "ith_number","the_total",
                                  "time_length","frequency",
                                  "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
      final_results_2
      
      return(final_results_2)
    } # if (proportion_0>=0.90 )
  }#if (situations=='No')
  
} # function EWs_do



EWs_do_response_weekly<-function (new_datas,leng_window,Yes_No){
  new_data=new_datas  
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  
  if (situations=='No'){final_results_2=NULL}else{
    if (proportion_0>=0.90 ){final_results_2=NULL}else{
      #common EWs + P value
      leng_window=leng_window # difine the length of time window
      number=100 # define the number of surrogates
      final_results_2=rbind(c(response_time(AR1(new_data$Incidence,leng_window,1),new_data),"AR1"),
                                       #c(response_time(AR2(new_data$Incidence,leng_window,1),new_data),"AR2"),
                                       #c(response_time(AR3(new_data$Incidence,leng_window,1),new_data),"AR3"),
                            c(response_time(SD(new_data$Incidence,leng_window,1),new_data),"SD"),
                            c(response_time(Skewness(new_data$Incidence,leng_window,1),new_data),"Skewness"),
                            c(response_time(Kurtosis(new_data$Incidence,leng_window,1),new_data),"Kurtosis"),
                            c(response_time(CV(new_data$Incidence,leng_window,1),new_data),"CV"),
                            c(response_time(first_differenced_variance(new_data$Incidence,leng_window,1),new_data),"first_differenced_variance"),
                            c(response_time(Autocovariance(new_data$Incidence,leng_window,1),new_data),"Autocovariance"),
                            c(response_time(index_of_dispersion(new_data$Incidence,leng_window,1),new_data),"index_of_dispersion"),
                            c(response_time(density_ratio(new_data$Incidence,leng_window,1),new_data),"density_ratio"),
                            
                            c(response_time(Max_eigen(new_data$Incidence,leng_window,1),new_data),"Max_eigen"),
                            
                            #vest function
                            c(response_time(relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))],new_data),"relative_dispersions"),
                            #c(response_time(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                            c(response_time(Hurst_exponents(new_data$Incidence,leng_window,1),new_data),"Hurst_exponents"),
                            c(response_time(time_series_acceleration(new_data$Incidence,leng_window,1),new_data),"time_series_acceleration"),
                            #c(response_time(Slopes(new_data$Incidence,leng_window,1),new_data),"Slopes"),
                            #c(response_time(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                            c(response_time(no_outliers(new_data$Incidence,leng_window,1),new_data),"no_outliers"),
                            #c(response_time(Step_changes(new_data$Incidence,leng_window,1),new_data),"Step_changes"),
                            c(response_time(N_peaks(new_data$Incidence,leng_window,1),new_data),"N_peaks"),
                            c(response_time(Turning_Points(new_data$Incidence,leng_window,1),new_data),"Turning_Points")
                            #c(response_time(FFT_AMP(new_data$Incidence,leng_window,1),new_data),"FFT_AMP"),
                            #c(response_time(poincare_variabilitys(new_data$Incidence,leng_window,1),new_data),"poincare_variabilitys")
                                          #c(response_time(wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_filtering"),
                                          #c(response_time(wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1),new_data),"wavelet_reddening")
      )
      
      final_results_2=as.data.frame(final_results_2)
      
      final_results_2$length_time_series=nrow(subs_data)
      final_results_2$i_number=i_number
      final_results_2$the_total=replicate_number
      final_results_2$time_length=length(new_data$Incidence)
      final_results_2$frequency=The_frequece
      final_results_2$disease=the_diseases
      final_results_2$country_region=the_countrys
      final_results_2$outbreaks=situations
      final_results_2$number=1
      final_results_2$leng_window=leng_window
      final_results_2$Yes_No=Yes_No
      colnames(final_results_2)=c("Responses_time","EWs",
                                  "length_time_series",
                                  "ith_number","the_total",
                                  "time_length","frequency",
                                  "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
      final_results_2
      
      return(final_results_2)
    } # if (proportion_0>=0.90 )
  }#if (situations=='No')
  
} # function EWs_do


# tau + responses time
EWs_do_responseFull<-function (new_datas,leng_window,Yes_No){
  new_data=new_datas  
  
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),response_time(AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),response_time(AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),response_time(AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),response_time(SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),response_time(Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),response_time(Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),response_time(CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),response_time(first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),response_time(Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),response_time(index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),response_time(density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          #c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),response_time(Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),response_time(relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),response_time(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),response_time(Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),response_time(time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),response_time(Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),response_time(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),response_time(no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),response_time(Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),response_time(N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),response_time(Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),response_time(FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),response_time(poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=the_outbreak
    final_results_2$number=situations
    final_results_2$leng_window=leng_window
    colnames(final_results_2)=c("Tau_original","P_value","trend",
                                "Responses_time","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","leng_window") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
    } # if
  

} # function EWs_do
