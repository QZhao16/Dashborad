library(mlbench)   #Version 2.1.3
library(Cubist)    #Version 0.4.2.1
library(tseriesChaos) #Version 0.1.13.1
library(TTR)       #Version 0.24.3
library(ifultools) #Version 2.0.26
library(wmtsa)     #Version 2.0.3
library(DescTools) #Version 0.99.49
library(scatterplot3d) #Version 0.3.44
library(forecast)   #Version 8.21
library(gtools)     #Version 3.9.4 
library(infotheo)   #Version 1.2.0.1
library(rEDM)       #Version 1.2.3
# inastall rEDM Version 1.2.3
#packageurl <- "http://cran.r-project.org/src/contrib/Archive/Matrix/rEDM_1.2.3.tar.gz"
#install.packages(packageurl, repos=NULL, type="source")
library(seasonal)#Version 1.9.0
library(ape)     #Version 5.7.1
library(rgee)    #Version 1.1.5
library(ggplot2) #Version 3.4.2
library(tidyr)   #Version 1.3.0
library(ggplot2) #Version 3.4.2
library(reticulate) #Version 1.28
library(earlywarnings) #Version 1.1.29
library(gridExtra) #Version 2.3
library(EpiEstim)  #version 4.1.3
library(MASS) #version 7.3.54
library(WaveletComp) #version 1.1-0
library(survival)

library(tidyverse)
library(dplyr)
