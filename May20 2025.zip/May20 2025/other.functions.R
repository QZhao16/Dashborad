Re<-function(subs_data) {

results_1=estimateRe(dates=subs_data$date,incidenceData=as.data.frame(subs_data$Incidence))
dim(results_1)
# extract Rt and confidence interval (CI) position
CI_upper_start=which(results_1$date==results_1$date[1])[2] #start date
CI_upper_end=which(results_1$date==results_1$date[length(results_1$date)])[2] #end date
mean_start=which(results_1$date==results_1$date[1])[1] #start date
mean_end=which(results_1$date==results_1$date[length(results_1$date)])[1] #end date
CI_lower_start=which(results_1$date==results_1$date[1])[3] #start date
CI_lower_end=which(results_1$date==results_1$date[length(results_1$date)])[3] #end date
#merge 
mean_Rt=as.data.frame( cbind(as.data.frame(results_1$date[mean_start:mean_end]),results_1$value[mean_start:mean_end]) )
colnames(mean_Rt)=c("date","Rt")
CI_Rt_uppper=as.data.frame( cbind(as.data.frame(results_1$date[CI_upper_start:CI_upper_end]),results_1$value[CI_upper_start:CI_upper_end]) )
colnames(CI_Rt_uppper)=c("date","CI_Rt_uppper")
CI_Rt_lower=as.data.frame( cbind(as.data.frame(results_1$date[CI_lower_start:CI_lower_end]),results_1$value[CI_lower_start:CI_lower_end]) )
colnames(CI_Rt_lower)=c("date","CI_Rt_lower")
finals1=merge(mean_Rt,CI_Rt_uppper,by="date")
finals2=merge(finals1,CI_Rt_lower,by="date")
dim(CI_Rt_uppper)
dim(finals2)
dim(subs_data)
subs_data=merge(finals2,subs_data,by="date")
head(subs_data)
subs_data=subs_data[!is.na(subs_data$Rt), ] # remove NA Rt
subs_data<-as.data.frame(subs_data)
return(subs_data)
}


start_end_outbreak<-function(date_position, subs_data){

#if (length(date_position)>1 | length(date_position)==0){ #exclude no-outbreaks and 1-outbreak (not accurate)
  
  outbreak_positions=date_position#find_two_aWeek(date_position)
  
  # find the outbreak-point which is right before the defining tipping point above
  outbreak_before_position<-function(subs_data,outbreak_positions){
    outbreak_before_poits=NULL
    #case 1
    if(length(outbreak_positions)==1) {
      if(date_position[1]<outbreak_positions){ # the first of date_position is also outbreak
        outbreak_positions_2<-date_position[which(date_position %in% outbreak_positions)-1] # the point before current outbreak point
        outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_positions_2,"%Y-%m-%d")) )
      } else {
        outbreak_before_poit=subs_data$date[1] #first day
        outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )}
    }#if
    #case2
    if(length(outbreak_positions)>=2) {
      for (i in 1:length(outbreak_positions)){
        #if (i==1){
        #  outbreak_before_poit=subs_data$date[1] #first day
        #  outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )
        #} 
        
        if(i==1) {
          if(date_position[1]<outbreak_positions[1]){ # the first of date_position is also outbreak
            outbreak_positions_2<-date_position[which(date_position %in% outbreak_positions[1])-1] # the point before current outbreak point
            outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_positions_2,"%Y-%m-%d")) )
          } else {
            outbreak_before_poit=subs_data$date[1] #first day
            outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )}
        }#if
        
        if (i>1){
          outbreak_positions_2<-date_position[which(date_position %in% outbreak_positions[i])-1] # the point before current outbreak point
          outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_positions_2,"%Y-%m-%d")) )  }
      }# for
    }#if
    return(outbreak_before_poits)
  } # outbreak_before_positions function
  
  outbreak_before_positions=outbreak_before_position(subs_data,outbreak_positions)
  
  # bind, star and end date
  start_end=NULL
  if(length(outbreak_positions)>0) {
    start_end<-as.data.frame(cbind(as.character(outbreak_before_positions),as.character(outbreak_positions)))
    colnames(start_end)<-c("start","end")
    start_end$start<-as.Date(start_end$start,"%Y-%m-%d");start_end$end<-as.Date(start_end$end,"%Y-%m-%d")
    start_end
  } 
  start_end
  
#}  if (length(date_position)>1 | length(date_position)==0){
  
  return(start_end)
}


#tau_time_series(start_end, subs_data)

#subs_data<-subs_data_2
tau_time_series<-function(start_end, subs_data){
  
  # PArt 1 load function
  
  #new_datas<-as.data.frame( rbind(subs_data_31,subs_data_31,subs_data_31,subs_data_31,subs_data_31) )
  ## EWs over moving window, after sep-15 2024
  single_EWs_do_TimeSeries<-function (new_datas,leng_window,Yes_No){
    Yes_No=Yes_No
    if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
      if (length(cbind(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
      if (length(cbind(start_end))==0) {situations<-the_outbreak;replicate_number=1}
    }
    
    if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
      situations<-'No';replicate_number=t_total}
    
    new_data=new_datas  
    proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
    #
    risk_model<-function(situations,lengthss,position) {
      if(situations=='No'){returns=rep(0,lengthss)}
      
      if(situations=='Yes'){
        if(lengthss==position | lengthss<position){returns=rep(0,lengthss);
        returns[lengthss]=1}                                                          #significant point as 1 in risk model
        if(lengthss>position ){returns=rep(0,lengthss);
        returns[1:(lengthss-position-1)]=0;returns[(lengthss-position):lengthss]=1} #significant point as 1 in risk model
      }
      return(returns)
    }
    
    risk2_model<-function(situations,lengthss,position) {
      if(situations=='No'){returns=rep(0,lengthss)}
      if(situations=='Yes'){returns=rep(0,lengthss);returns[lengthss]=1} #Always the last point as 1 in risk model
      return(returns)
    }
    
    
    #
    if (proportion_0>=0.90){final_results_2=NULL}else{
      #common EWs + P value
      leng_window=leng_window # difine the length of time window
      number=100 # define the number of surrogates
      
      # tau time series
      # AR1_a=AR1(new_data$Incidence,leng_window,1)
      # AR2_a=AR2(new_data$Incidence,leng_window,1)
      # AR3_a=AR3(new_data$Incidence,leng_window,1)
      # SD_a=SD(new_data$Incidence,leng_window,1)
      # Skewness_a=Skewness(new_data$Incidence,leng_window,1)
      # Kurtosis_a=Kurtosis(new_data$Incidence,leng_window,1)
      # CV_a=CV(new_data$Incidence,leng_window,1)
      # first_differenced_variance_a=first_differenced_variance(new_data$Incidence,leng_window,1)
      # Autocovariance_a=Autocovariance(new_data$Incidence,leng_window,1)
      index_of_dispersion_a=index_of_dispersion(new_data$Incidence,leng_window,1)
      # density_ratio_a=density_ratio(new_data$Incidence,leng_window,1)
      # 
      # relative_dispersions_a=relative_dispersions(new_data$Incidence,leng_window,1)
      # Hurst_exponents_a=Hurst_exponents(new_data$Incidence,leng_window,1)
      # time_series_acceleration_a=time_series_acceleration(new_data$Incidence,leng_window,1)
      # no_outliers_a=no_outliers(new_data$Incidence,leng_window,1)
      # Turning_Points_a=Turning_Points(new_data$Incidence,leng_window,1)
      # Max_eigen_a=Max_eigen(new_data$Incidence,leng_window,1)
      # wavelet_filterings_a=wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)
      # wavelet_reddenings_a=wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)
      
      # risk model
      # risk_AR1=risk_model(situations,length(AR1_a),response_time(AR1_a,new_data))
      # risk_AR2=risk_model(situations,length(AR2_a),response_time(AR2_a,new_data))
      # risk_AR3=risk_model(situations,length(AR3_a),response_time(AR3_a,new_data))
      # risk_SD=risk_model(situations,length(SD_a),response_time(SD_a,new_data))
      # risk_Skewness=risk_model(situations,length(Skewness_a),response_time(Skewness_a,new_data))
      # risk_Kurtosis=risk_model(situations,length(Kurtosis_a),response_time(Kurtosis_a,new_data))
      # risk_CV=risk_model(situations,length(CV_a),response_time(CV_a,new_data))
      # risk_first_differenced_variance=risk_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a,new_data))
      # risk_Autocovariance=risk_model(situations,length(Autocovariance_a),response_time(Autocovariance_a,new_data))
      risk_index_of_dispersion=risk_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a,new_data))
      # risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
      # risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
      # risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
      # 
      # risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
      # risk_Hurst_exponents=risk_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a,new_data))
      # risk_time_series_acceleration=risk_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a,new_data))
      # risk_no_outliers=risk_model(situations,length(no_outliers_a),response_time(no_outliers_a,new_data))
      # risk_Turning_Points=risk_model(situations,length(Turning_Points_a),response_time(Turning_Points_a,new_data))
      # risk_Max_eigen=risk_model(situations,length(Max_eigen_a),response_time(Max_eigen_a,new_data))
      # risk_wavelet_filtering=risk_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a,new_data))
      # risk_wavelet_reddening=risk_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a,new_data))
      
      # risk model2
      # risk2_AR1=risk2_model(situations,length(AR1_a),response_time(AR1_a,new_data))
      # risk2_AR2=risk2_model(situations,length(AR2_a),response_time(AR2_a,new_data,new_data))
      # risk2_AR3=risk2_model(situations,length(AR3_a),response_time(AR3_a,new_data))
      # risk2_SD=risk2_model(situations,length(SD_a),response_time(SD_a,new_data))
      # risk2_Skewness=risk2_model(situations,length(Skewness_a),response_time(Skewness_a,new_data))
      # risk2_Kurtosis=risk2_model(situations,length(Kurtosis_a),response_time(Kurtosis_a,new_data))
      # risk2_CV=risk2_model(situations,length(CV_a),response_time(CV_a,new_data))
      # risk2_first_differenced_variance=risk2_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a,new_data))
      # risk2_Autocovariance=risk2_model(situations,length(Autocovariance_a),response_time(Autocovariance_a,new_data))
      risk2_index_of_dispersion=risk2_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a,new_data))
      # risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
      # risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
      # risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
      # 
      # risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
      # risk2_Hurst_exponents=risk2_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a,new_data))
      # risk2_time_series_acceleration=risk2_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a,new_data))
      # 
      # risk2_no_outliers=risk2_model(situations,length(no_outliers_a),response_time(no_outliers_a,new_data))
      # 
      # risk2_Turning_Points=risk2_model(situations,length(Turning_Points_a),response_time(Turning_Points_a,new_data))
      # 
      # risk2_Max_eigen=risk2_model(situations,length(Max_eigen_a),response_time(Max_eigen_a,new_data))
      # risk2_wavelet_filterings=risk2_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a,new_data))
      # risk2_wavelet_reddenings=risk2_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a,new_data))
      
      final_results_2=rbind(
        # cbind(seq(1,length(AR1_a),by=1), AR1_a,rep(ken_p(AR1_a)[1],length(AR1_a)), rep(ken_p(AR1_a)[2],length(AR1_a)), temperature_mean(TAVG,leng_window,1)[length(AR1_a)],risk_AR1,risk2_AR1, time_seg(new_data$date,leng_window,1), rep("AR1",length(AR1_a))),
        # cbind(seq(1,length(AR2_a),by=1), AR2_a,rep(ken_p(AR2_a)[1],length(AR2_a)), rep(ken_p(AR2_a)[2],length(AR2_a)), temperature_mean(TAVG,leng_window,1)[length(AR2_a)],risk_AR2,risk2_AR2, time_seg(new_data$date,leng_window,1),rep("AR2",length(AR2_a))),
        # cbind(seq(1,length(AR3_a),by=1), AR3_a,rep(ken_p(AR3_a)[1],length(AR3_a)), rep(ken_p(AR3_a)[2],length(AR3_a)), temperature_mean(TAVG,leng_window,1)[length(AR3_a)],risk_AR3,risk2_AR3,time_seg(new_data$date,leng_window,1), rep("AR3",length(AR3_a))),
        # cbind(seq(1,length(SD_a),by=1), SD_a,rep(ken_p(SD_a)[1],length(SD_a)), rep(ken_p(SD_a)[2],length(SD_a)), temperature_mean(TAVG,leng_window,1)[length(SD_a)],risk_SD,risk2_SD,time_seg(new_data$date,leng_window,1), rep("SD",length(SD_a))),
        # cbind(seq(1,length(Skewness_a),by=1), Skewness_a,rep(ken_p(Skewness_a)[1],length(Skewness_a)), rep(ken_p(Skewness_a)[2],length(Skewness_a)), temperature_mean(TAVG,leng_window,1)[length(Skewness_a)],risk_Skewness,risk2_Skewness,time_seg(new_data$date,leng_window,1), rep("Skewness",length(Skewness_a))),
        # cbind(seq(1,length(Kurtosis_a),by=1), Kurtosis_a,rep(ken_p(Kurtosis_a)[1],length(Kurtosis_a)), rep(ken_p(Kurtosis_a)[2],length(Kurtosis_a)), temperature_mean(TAVG,leng_window,1)[length(Kurtosis_a)],risk_Kurtosis,risk2_Kurtosis,time_seg(new_data$date,leng_window,1), rep("Kurtosis",length(Kurtosis_a))),
        # cbind(seq(1,length(CV_a),by=1), CV_a,rep(ken_p(CV_a)[1],length(CV_a)), rep(ken_p(CV_a)[2],length(CV_a)), temperature_mean(TAVG,leng_window,1)[length(CV_a)],risk_CV,risk2_CV,time_seg(new_data$date,leng_window,1), rep("CV",length(CV_a))),
        # cbind(seq(1,length(first_differenced_variance_a),by=1), first_differenced_variance_a,rep(ken_p(first_differenced_variance_a)[1],length(first_differenced_variance_a)), rep(ken_p(first_differenced_variance_a)[2],length(first_differenced_variance_a)), temperature_mean(TAVG,leng_window,1)[length(first_differenced_variance_a)],risk_first_differenced_variance,risk2_first_differenced_variance,time_seg(new_data$date,leng_window,1), rep("first_differenced_variance",length(first_differenced_variance_a))),
        # cbind(seq(1,length(Autocovariance_a),by=1), Autocovariance_a,rep(ken_p(Autocovariance_a)[1],length(Autocovariance_a)), rep(ken_p(Autocovariance_a)[2],length(Autocovariance_a)), temperature_mean(TAVG,leng_window,1)[length(Autocovariance_a)],risk_Autocovariance,risk2_Autocovariance,time_seg(new_data$date,leng_window,1), rep("Autocovariance",length(Autocovariance_a))),
        # cbind(seq(1,length(index_of_dispersion_a),by=1), index_of_dispersion_a,rep(ken_p(index_of_dispersion_a)[1],length(index_of_dispersion_a)), rep(ken_p(index_of_dispersion_a)[2],length(index_of_dispersion_a)), temperature_mean(TAVG,leng_window,1)[length(index_of_dispersion_a)],risk_index_of_dispersion,risk2_index_of_dispersion,time_seg(new_data$date,leng_window,1), rep("index_of_dispersion",length(index_of_dispersion_a))),
        cbind(seq(1,length(index_of_dispersion_a),by=1), index_of_dispersion_a,rep(ken_p(index_of_dispersion_a)[1],length(index_of_dispersion_a)), rep(ken_p(index_of_dispersion_a)[2],length(index_of_dispersion_a)),                                                                      risk_index_of_dispersion,risk2_index_of_dispersion,time_seg(new_data$date,leng_window,1), rep("index_of_dispersion",length(index_of_dispersion_a)))
        # cbind(seq(1,length(density_ratio_a),by=1), density_ratio_a,rep(ken_p(density_ratio_a)[1],length(density_ratio_a)), rep(ken_p(density_ratio_a)[2],length(density_ratio_a)), temperature_mean(TAVG,leng_window,1)[length(density_ratio_a)],risk_density_ratio,risk2_density_ratio,time_seg(new_data$date,leng_window,1), rep("density_ratio",length(density_ratio_a))),
        
        #vest function
        # cbind(seq(1,length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))]),by=1), relative_dispersions_a[!(is.infinite(relative_dispersions_a))],rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[1],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[2],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), 
        #       temperature_mean(TAVG[1:nrow(new_data)],leng_window,1)[!(is.infinite(relative_dispersions_a))], 
        #       risk_relative_dispersions[!(is.infinite(relative_dispersions_a))],
        #       risk2_relative_dispersions[!(is.infinite(relative_dispersions_a))],
        #       time_seg(new_data$date,leng_window,1)[!(is.infinite(relative_dispersions_a)),],
        #       rep("relative_dispersions",length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))]))),
        # 
        #       cbind(seq(1,length(Hurst_exponents_a),by=1), Hurst_exponents_a,rep(ken_p(Hurst_exponents_a)[1],length(Hurst_exponents_a)), rep(ken_p(Hurst_exponents_a)[2],length(Hurst_exponents_a)), temperature_mean(TAVG,leng_window,1)[length(Hurst_exponents_a)],risk_Hurst_exponents,risk2_Hurst_exponents,time_seg(new_data$date,leng_window,1), rep("Hurst_exponents",length(Hurst_exponents_a))),
        #       cbind(seq(1,length(time_series_acceleration_a),by=1), time_series_acceleration_a,rep(ken_p(time_series_acceleration_a)[1],length(time_series_acceleration_a)), rep(ken_p(time_series_acceleration_a)[2],length(time_series_acceleration_a)), 
        #             temperature_mean(TAVG,leng_window,1)[length(time_series_acceleration_a)],
        #             risk_time_series_acceleration,
        #             risk2_time_series_acceleration,
        #             time_seg(new_data$date,leng_window,1), 
        #             rep("time_series_acceleration",length(time_series_acceleration_a))),
        
        # cbind(seq(1,length(no_outliers_a),by=1), no_outliers_a,rep(ken_p(no_outliers_a)[1],length(no_outliers_a)), rep(ken_p(no_outliers_a)[2],length(no_outliers_a)), temperature_mean(TAVG,leng_window,1)[length(no_outliers_a)],risk_no_outliers,risk2_no_outliers,time_seg(new_data$date,leng_window,1), rep("no_outliers",length(no_outliers_a))),
        # 
        # cbind(seq(1,length(Turning_Points_a),by=1), Turning_Points_a,rep(ken_p(Turning_Points_a)[1],length(Turning_Points_a)), rep(ken_p(Turning_Points_a)[2],length(Turning_Points_a)), temperature_mean(TAVG,leng_window,1)[length(Turning_Points_a)],risk_Turning_Points,risk2_Turning_Points,time_seg(new_data$date,leng_window,1), rep("Turning_Points",length(Turning_Points_a))),
        # 
        # cbind(seq(1,length(Max_eigen_a),by=1), Max_eigen_a,rep(ken_p(Max_eigen_a)[1],length(Max_eigen_a)), rep(ken_p(Max_eigen_a)[2],length(Max_eigen_a)), temperature_mean(TAVG,leng_window,1)[length(Max_eigen_a)],risk_Max_eigen,risk2_Max_eigen, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(Max_eigen_a))),
        # cbind(seq(1,length(wavelet_filterings_a),by=1), wavelet_filterings_a,rep(ken_p(wavelet_filterings_a)[1],length(wavelet_filterings_a)), rep(ken_p(wavelet_filterings_a)[2],length(wavelet_filterings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_filterings_a)],risk_wavelet_filtering,risk2_wavelet_filterings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_filterings_a))),
        # cbind(seq(1,length(wavelet_reddenings_a),by=1), wavelet_reddenings_a,rep(ken_p(wavelet_reddenings_a)[1],length(wavelet_reddenings_a)), rep(ken_p(wavelet_reddenings_a)[2],length(wavelet_reddenings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_reddenings_a)],risk_wavelet_reddening,risk2_wavelet_reddenings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_reddenings_a)))
        
      )
      
      final_results_2=as.data.frame(final_results_2)
      
      final_results_2$i_number=i_number
      final_results_2$the_total=replicate_number
      final_results_2$time_length=length(new_data$Incidence)
      final_results_2$length_time_series=nrow(subs_data)
      final_results_2$frequency=The_frequece
      final_results_2$disease=the_diseases
      final_results_2$country_region=the_countrys
      final_results_2$outbreaks=situations
      final_results_2$number=1
      final_results_2$leng_window=leng_window
      final_results_2$Yes_No=Yes_No
      colnames(final_results_2)=cbind("seq_length","Ews_timeSeries","tau_value","p_value",#"temperature",
                                      "outbreak_posit1","outbreak_posit2", #outbreak_posit1 treat the significant as 1 in risk model, while the outbreak_posit2 treat the last as 1
                                      "date1","date2",
                                      #"trend",
                                      "EWs",
                                      "ith_number","the_total",
                                      "time_length_sub","length_time_series","frequency",
                                      "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
      final_results_2
      
      return(final_results_2)
    } # if
    
    
  } # function EWs_do
  
  
  
  
  
  
  ### Part 2
  first_start<-NULL
  
  #find lowest 5% CI, where previous outbreak-wave completely ended 
  subs_data_31=subs_data_32=subs_data_33=subs_data_34=
    subs_data_35=subs_data_36=subs_data_36=subs_data_37=
    subs_data_38=subs_data_39=subs_data_310=subs_data_311=
    subs_data_312=NULL  
  i=1
  if (length(c(start_end))==0){subs_data_31<-subs_data} else {
    for (i in 1:nrow(start_end)){
      if (i==1){ 
        if (start_end$start[1]==subs_data$date[1]){
          starts<-1
          ends<-which(subs_data$date %in% start_end$end[1])
          subs_data_31<-subs_data[starts:ends,]
        }else{
          starts<-which(subs_data$date %in% start_end$start[1])
          ends<-which(subs_data$date %in% start_end$end[1])
          subs_data_2<-subs_data[starts:ends,]
          lowest<-which(subs_data_2$Low.confidence.interval.Re %in% min(subs_data_2$Low.confidence.interval.Re)[1]);
          subs_data_31<-subs_data_2[lowest:nrow(subs_data_2),]}#else
      }#if
      if (i==2){
        starts2<-which(subs_data$date %in% start_end$start[2])
        ends2<-which(subs_data$date %in% start_end$end[2])
        subs_data_22<-subs_data[starts2:ends2,]
        lowest2<-which(subs_data_22$Low.confidence.interval.Re %in% min(subs_data_22$Low.confidence.interval.Re)[1]);
        subs_data_32<-subs_data_22[lowest2:nrow(subs_data_22),]   }
      if (i==3){
        starts3<-which(subs_data$date %in% start_end$start[3])
        ends3<-which(subs_data$date %in% start_end$end[3])
        subs_data_23<-subs_data[starts3:ends3,]
        lowest3<-which(subs_data_23$Low.confidence.interval.Re %in% min(subs_data_23$Low.confidence.interval.Re)[1]);
        subs_data_33<-subs_data_23[lowest3:nrow(subs_data_23),]   }
      if (i==4){
        starts4<-which(subs_data$date %in% start_end$start[4])
        ends4<-which(subs_data$date %in% start_end$end[4])
        subs_data_24<-subs_data[starts4:ends4,]
        lowest4<-which(subs_data_24$Low.confidence.interval.Re %in% min(subs_data_24$Low.confidence.interval.Re)[1]);
        subs_data_34<-subs_data_24[lowest4:nrow(subs_data_24),]   }
      if (i==5){
        starts5<-which(subs_data$date %in% start_end$start[5])
        ends5<-which(subs_data$date %in% start_end$end[5])
        subs_data_25<-subs_data[starts5:ends5,]
        lowest5<-which(subs_data_25$Low.confidence.interval.Re %in% min(subs_data_25$Low.confidence.interval.Re)[1]);
        subs_data_35<-subs_data_25[lowest5:nrow(subs_data_25),]   }
      if (i==6){
        starts6<-which(subs_data$date %in% start_end$start[6])
        ends6<-which(subs_data$date %in% start_end$end[6])
        subs_data_26<-subs_data[starts6:ends6,]
        lowest6<-which(subs_data_26$Low.confidence.interval.Re %in% min(subs_data_26$Low.confidence.interval.Re)[1]);
        subs_data_36<-subs_data_26[lowest6:nrow(subs_data_26),]   }
      if (i==7){
        starts7<-which(subs_data$date %in% start_end$start[7])
        ends7<-which(subs_data$date %in% start_end$end[7])
        subs_data_27<-subs_data[starts7:ends7,]
        lowest7<-which(subs_data_27$Low.confidence.interval.Re %in% min(subs_data_27$Low.confidence.interval.Re)[1]);
        subs_data_37<-subs_data_27[lowest7:nrow(subs_data_27),]   }
      if (i==8){
        starts8<-which(subs_data$date %in% start_end$start[8])
        ends8<-which(subs_data$date %in% start_end$end[8])
        subs_data_28<-subs_data[starts8:ends8,]
        lowest8<-which(subs_data_28$Low.confidence.interval.Re %in% min(subs_data_28$Low.confidence.interval.Re)[1]);
        subs_data_38<-subs_data_28[lowest8:nrow(subs_data_28),]   }
      if (i==9){
        starts9<-which(subs_data$date %in% start_end$start[9])
        ends9<-which(subs_data$date %in% start_end$end[9])
        subs_data_29<-subs_data[starts9:ends9,]
        lowest9<-which(subs_data_29$Low.confidence.interval.Re %in% min(subs_data_29$Low.confidence.interval.Re)[1]);
        subs_data_39<-subs_data_29[lowest9:nrow(subs_data_29),]   }
      if (i==10){
        starts10<-which(subs_data$date %in% start_end$start[10])
        ends10<-which(subs_data$date %in% start_end$end[10])
        subs_data_210<-subs_data[starts10:ends10,]
        lowest10<-which(subs_data_210$Low.confidence.interval.Re %in% min(subs_data_210$Low.confidence.interval.Re)[1]);
        subs_data_310<-subs_data_210[lowest10:nrow(subs_data_210),]   }
      if (i==11){
        starts11<-which(subs_data$date %in% start_end$start[11])
        ends11<-which(subs_data$date %in% start_end$end[11])
        subs_data_211<-subs_data[starts11:ends11,]
        lowest11<-which(subs_data_211$Low.confidence.interval.Re %in% min(subs_data_211$Low.confidence.interval.Re)[1]);
        subs_data_311<-subs_data_211[lowest11:nrow(subs_data_211),]   }
      if (i==12){
        starts12<-which(subs_data$date %in% start_end$start[12])
        ends12<-which(subs_data$date %in% start_end$end[12])
        subs_data_212<-subs_data[starts12:ends12,]
        lowest12<-which(subs_data_212$Low.confidence.interval.Re %in% min(subs_data_212$Low.confidence.interval.Re)[1]);
        subs_data_312<-subs_data_212[lowest12:nrow(subs_data_212),]   }
      
    } #for
  } #else
  
  
  #### function
  if (length(c(start_end))==0){the_outbreak="No"} else {the_outbreak="Yes"} 
  
  threshold<-leng_window+3
  
  i=1
  the_total=0
  if (length(c(start_end))==0 ){
    if(nrow(subs_data_31)>=leng_window+3 ){
      new_datas=subs_data_31;i_number=1;
      Yes_No=1
      resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No)
      if (length(c(resultsl))!=0){
        #first_start=rbind(first_start, single_EWs_do_TimeSeries(new_datas,leng_window))
        first_start=rbind(first_start,cbind(resultsl,start_day=new_datas$date[1],end_day=tail(new_datas$date,n=1)))
      } 
    }}
  
  
  i_number=NULL
  if (length(c(start_end))>=1){
    
    t2_total<-t2_totals(start_end) #total replicate in single disease with judging within first_start (Yes or No outbreaks)
    Yes_No=1
    for (i_number in 1:nrow(start_end)){
      if(i_number==1){if (nrow(subs_data_31)>=leng_window+3){ new_datas=subs_data_31;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_31$date[1],end_day=tail(subs_data_31$date,n=1))) }}}
      if(i_number==2){if (nrow(subs_data_32)>=leng_window+3){ new_datas=subs_data_32;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_32$date[1],end_day=tail(subs_data_32$date,n=1))) }}}
      if(i_number==3){if (nrow(subs_data_33)>=leng_window+3){ new_datas=subs_data_33;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_33$date[1],end_day=tail(subs_data_33$date,n=1))) }}}
      if(i_number==4){if (nrow(subs_data_34)>=leng_window+3){ new_datas=subs_data_34;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_34$date[1],end_day=tail(subs_data_34$date,n=1))) }}}
      if(i_number==5){if (nrow(subs_data_35)>=leng_window+3){ new_datas=subs_data_35;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_35$date[1],end_day=tail(subs_data_35$date,n=1))) }}}
      if(i_number==6){if (nrow(subs_data_36)>=leng_window+3){ new_datas=subs_data_36;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_36$date[1],end_day=tail(subs_data_36$date,n=1))) }}}
      if(i_number==7){if (nrow(subs_data_37)>=leng_window+3){ new_datas=subs_data_37;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_37$date[1],end_day=tail(subs_data_37$date,n=1))) }}}
      if(i_number==8){if (nrow(subs_data_38)>=leng_window+3){ new_datas=subs_data_38;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_38$date[1],end_day=tail(subs_data_38$date,n=1))) }}}
      if(i_number==9){if (nrow(subs_data_39)>=leng_window+3){ new_datas=subs_data_39;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_39$date[1],end_day=tail(subs_data_39$date,n=1))) }}}
      if(i_number==10){if (nrow(subs_data_310)>=leng_window+3){ new_datas=subs_data_310;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_310$date[1],end_day=tail(subs_data_310$date,n=1)))}}}
      if(i_number==11){if (nrow(subs_data_311)>=leng_window+3){ new_datas=subs_data_311;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_311$date[1],end_day=tail(subs_data_311$date,n=1)))}}}
      if(i_number==12){if (nrow(subs_data_312)>=leng_window+3){ new_datas=subs_data_312;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=subs_data_312$date[1],end_day=tail(subs_data_312$date,n=1)))}}}
    }#for
    
  } #if (length(c(start_end))>=1)
  
  
  ########
  # No outbreaks time segnament within the outbreaks time series
  #######
  #find "No" outbreaks in time series
  su_data_30=su_data_31=su_data_32=su_data_33=su_data_34=
    su_data_35=su_data_36=su_data_36=su_data_37=
    su_data_38=su_data_39=su_data_310=su_data_311=
    su_data_312=NULL  
  i=1
  if (length(c(start_end))>=1){
    i=1
    for (i in 1:nrow(start_end)){
      if (i==1){ 
        if (start_end$start[1]==subs_data$date[1]){
          su_data_31<-subs_data[1,]
        }else{
          starts<-1
          ends<-which(subs_data$date %in% start_end$start[1])
          su_data_31<-subs_data[starts:ends,]}#else
      }#if
      if (i==2){
        starts2<-which(subs_data$date %in% start_end$end[1])
        ends2<-which(subs_data$date %in% start_end$start[2])
        su_data_32<-subs_data[starts2:ends2,]  }
      if (i==3){
        starts3<-which(subs_data$date %in% start_end$end[2])
        ends3<-which(subs_data$date %in% start_end$start[3])
        su_data_33<-subs_data[starts3:ends3,]  }
      if (i==4){
        starts4<-which(subs_data$date %in% start_end$end[3])
        ends4<-which(subs_data$date %in% start_end$start[4])
        su_data_34<-subs_data[starts4:ends4,]  }
      if (i==5){
        starts5<-which(subs_data$date %in% start_end$end[4])
        ends5<-which(subs_data$date %in% start_end$start[5])
        su_data_35<-subs_data[starts5:ends5,]  }
      if (i==6){
        starts6<-which(subs_data$date %in% start_end$end[5])
        ends6<-which(subs_data$date %in% start_end$start[6])
        su_data_36<-subs_data[starts6:ends6,]  }
      if (i==7){
        starts7<-which(subs_data$date %in% start_end$end[6])
        ends7<-which(subs_data$date %in% start_end$start[7])
        su_data_37<-subs_data[starts7:ends7,]  }
      if (i==8){
        starts8<-which(subs_data$date %in% start_end$end[7])
        ends8<-which(subs_data$date %in% start_end$start[8])
        su_data_38<-subs_data[starts8:ends8,]  }
      if (i==9){
        starts9<-which(subs_data$date %in% start_end$end[8])
        ends9<-which(subs_data$date %in% start_end$start[9])
        su_data_39<-subs_data[starts9:ends9,]  }
      if (i==10){
        starts10<-which(subs_data$date %in% start_end$end[9])
        ends10<-which(subs_data$date %in% start_end$start[10])
        su_data_310<-subs_data[starts10:ends10,]  }
      if (i==11){
        starts11<-which(subs_data$date %in% start_end$end[10])
        ends11<-which(subs_data$date %in% start_end$start[11])
        su_data_311<-subs_data[starts11:ends11,]  }
      if (i==12){
        starts12<-which(subs_data$date %in% start_end$end[11])
        ends12<-which(subs_data$date %in% start_end$start[12])
        su_data_312<-subs_data[starts12:ends12,]  }
    }#for (i in 1:length(c(start_end)))
    
    # till end date
    if (start_end$end[nrow(start_end)]==subs_data$date[nrow(subs_data)]){
      su_data_30<-subs_data[nrow(subs_data),]
    }else{
      starts0<-which(subs_data$date %in% start_end$end[nrow(start_end)])
      ends0<-nrow(subs_data)
      su_data_30<-subs_data[starts0:ends0,]}#else
    
  } #if (length(c(start_end))>0){
  
  
  i_number=NULL
  if (length(c(start_end))>=1){
    
    t_total<-t_totals(start_end) #total replicate in single disease with 0 outbreak
    Yes_No=0
    for (i_number in 1:nrow(start_end)){
      if (nrow(su_data_30)>=leng_window+3){ new_datas=su_data_30;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_30$date[1],end_day=tail(su_data_30$date,n=1))) }}
      if(i_number==1){if (nrow(su_data_31)>=leng_window+3){ new_datas=su_data_31;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_31$date[1],end_day=tail(su_data_31$date,n=1))) }}}
      if(i_number==2){if (nrow(su_data_32)>=leng_window+3){ new_datas=su_data_32;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_32$date[1],end_day=tail(su_data_32$date,n=1))) }}}
      if(i_number==3){if (nrow(su_data_33)>=leng_window+3){ new_datas=su_data_33;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_33$date[1],end_day=tail(su_data_33$date,n=1))) }}}
      if(i_number==4){if (nrow(su_data_34)>=leng_window+3){ new_datas=su_data_34;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_34$date[1],end_day=tail(su_data_34$date,n=1))) }}}
      if(i_number==5){if (nrow(su_data_35)>=leng_window+3){ new_datas=su_data_35;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_35$date[1],end_day=tail(su_data_35$date,n=1))) }}}
      if(i_number==6){if (nrow(su_data_36)>=leng_window+3){ new_datas=su_data_36;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_36$date[1],end_day=tail(su_data_36$date,n=1))) }}}
      if(i_number==7){if (nrow(su_data_37)>=leng_window+3){ new_datas=su_data_37;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_37$date[1],end_day=tail(su_data_37$date,n=1))) }}}
      if(i_number==8){if (nrow(su_data_38)>=leng_window+3){ new_datas=su_data_38;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_38$date[1],end_day=tail(su_data_38$date,n=1))) }}}
      if(i_number==9){if (nrow(su_data_39)>=leng_window+3){ new_datas=su_data_39;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_39$date[1],end_day=tail(su_data_39$date,n=1))) }}}
      if(i_number==10){if (nrow(su_data_310)>=leng_window+3){ new_datas=su_data_310;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_310$date[1],end_day=tail(su_data_310$date,n=1)))}}}
      if(i_number==11){if (nrow(su_data_311)>=leng_window+3){ new_datas=su_data_311;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_311$date[1],end_day=tail(su_data_311$date,n=1)))}}}
      if(i_number==12){if (nrow(su_data_312)>=leng_window+3){ new_datas=su_data_312;resultsl=single_EWs_do_TimeSeries(new_datas,leng_window,Yes_No);if (length(c( resultsl))!=0){first_start=rbind(first_start,cbind( resultsl,start_day=su_data_312$date[1],end_day=tail(su_data_312$date,n=1)))}}}
    }#for
  } #if (length(c(start_end))>=1)
  
  
  
  return(first_start)
}















# total replicate in single disease with "No" outbreak
## total replicate in single disease with judging beyond first_start
t_totals<-function(start_end){
  t_total=0
if (length(c(start_end))>=1){
  for (i_number in 1:nrow(start_end)){
    
    if (nrow(su_data_30)>=leng_window+3){t_total=t_total+1}
      
    if(i_number==1){if (nrow(su_data_31)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==2){if (nrow(su_data_32)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==3){if (nrow(su_data_33)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==4){if (nrow(su_data_34)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==5){if (nrow(su_data_35)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==6){if (nrow(su_data_36)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==7){if (nrow(su_data_37)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==8){if (nrow(su_data_38)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==9){if (nrow(su_data_39)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==10){if (nrow(su_data_310)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==11){if (nrow(su_data_311)>=leng_window+3){ t_total=t_total+1}}
    if(i_number==12){if (nrow(su_data_312)>=leng_window+3){ t_total=t_total+1}}
  }#for
}
 return(t_total) 
}

#t_totals(start_end)

# total replicate in single disease with judging within first_start (Yes or No outbreaks)
t2_totals<-function(start_end){
  t2_total=0
  if (length(c(start_end))>=1){
    for (i_number in 1:nrow(start_end)){
      if(i_number==1){if (nrow(subs_data_31)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==2){if (nrow(subs_data_32)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==3){if (nrow(subs_data_33)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==4){if (nrow(subs_data_34)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==5){if (nrow(subs_data_35)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==6){if (nrow(subs_data_36)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==7){if (nrow(subs_data_37)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==8){if (nrow(subs_data_38)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==9){if (nrow(subs_data_39)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==10){if (nrow(subs_data_310)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==11){if (nrow(subs_data_311)>=leng_window+3){ t2_total=t2_total+1}}
      if(i_number==12){if (nrow(subs_data_312)>=leng_window+3){ t2_total=t2_total+1}}
    }#for
  }
  return(t2_total) 
}

#t2_totals(start_end)


##### find the data frequency
The_frequecyss<-function(subs_data){
  same_year=subs_data[format(subs_data$date,'%Y') %in% format(subs_data$date,'%Y')[1],"date"]
  same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[1]]
  if (length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
  if(The_frequecys==1){The_frequecys="daily"}
  if(The_frequecys==7){The_frequecys="weekly"}
  }#if
  
  if (length(same_month)==1 && !(format(same_month,'%m')==12) ){
    same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[2]]
    if(length(same_month)==1){The_frequecys="monthly"}
    if(length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
    if(The_frequecys==1){The_frequecys="daily"}
    if(The_frequecys==7){The_frequecys="weekly"}  }
  }#if
  
  if (length(same_month)==1 && format(same_month,'%m')==12 ){
    same_year=subs_data[format(subs_data$date,'%Y') %in% unique(format(subs_data$date,'%Y'))[2],"date"]
    same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[1]]
    if(length(same_month)==1){The_frequecys="monthly"}
    if(length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
    if(The_frequecys==1){The_frequecys="daily"}
    if(The_frequecys==7){The_frequecys="weekly"}  }
  }#if
  
  return(The_frequecys)
}#dunction


orthogonal_4<-function(modifys3,N_targetColmn){
  # PCA
  modifys3=modifys3
  # Extract the fourth column variable
  variable_of_interest <- modifys3[, N_targetColmn]
  # Generate example data with 21 variables
  data_matrix <- modifys3[, -N_targetColmn]  # Exclude the fourth column
  # Perform PCA
  pca_result <- prcomp(data_matrix, scale = TRUE)
  # Extract the loadings for the first principal component
  loadings_first_pc <- pca_result$rotation[, 1]
  # Identify the indices of the top 4 variables with the closest orthogonal angles
  selected_indices <- order(abs(loadings_first_pc - cor(variable_of_interest, data_matrix)), decreasing = FALSE)[1:7] #[1:4]
  
  # Output the selected variables
  selected_variables <- colnames(data_matrix)[selected_indices]
  #print(selected_variables)
  
  # Visualize the PCA results using a biplot without numbers
  #biplot(pca_result, col = c("white", "deeppink3"), cex = 0.5)
  
  return(selected_variables)
}




#### cross validation for ROC/AUC
CV_AUC<-function(data_fin2_1){
  # Prepare the dataset
  iris_binary <- data_fin2_1 %>%
    filter(Tau_original != "NA") %>% filter(P_value != "NA") %>% filter(frequency == "daily") %>%
    mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
  #
  iris_binary=iris_binary[,c("Tau_original","P_value","Species")]
  # Setup training control for k-fold cross-validation
  
  set.seed(1234) # repate CV 100 times
  seds<-sample(0:1000, 100, replace = FALSE)
  
  each_auc=NULL
  for (z in seds){
  set.seed(z)  # for reproducibility
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  
  # manually Calculate AUC, by manually doing from saved predictions
  #auc_scores <- lapply(split(model$pred, model$pred$Resample), function(subset) {
  #  roc_response <- roc(subset$obs, subset$Positive)
  #  auc(roc_response)
  #})
  #mean(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
  #sd(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
  #hist(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
  
  # automatically access the results
  results <- model$results 
  results
  #mean_auc <- mean(results$ROC) #mean AUC
  #sd_auc <- sd(results$ROC) # SD AUC
  model$results$ROC #mean AUC
  model$results$ROCSD # SD AUC
  
  each_auc=c(each_auc, model$results$ROC)
  }
  
  return( c( mean(each_auc),sd(each_auc) ) ) # for all K-fold
  #return(c(model$results$ROC,model$results$ROCSD)) # for single K-fold
}



#### cross validation for ROC/AUC
CV_AUC_single<-function(data_fin2_1){
  # Prepare the dataset
  iris_binary <- data_fin2_1 %>%
    filter(Tau_original != "NA") %>% filter(P_value != "NA") %>% filter(frequency == "daily") %>%
    mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
  #
  iris_binary=iris_binary[,c("Tau_original","P_value","Species")]
  # Setup training control for k-fold cross-validation
  
  set.seed(1234) 
  
    train_control <- trainControl(
      method = "cv", 
      number = 5,  # using 10 folds
      summaryFunction = twoClassSummary,  # custom summary function to get AUC
      classProbs = TRUE,  # necessary for AUC calculation
      savePredictions = "final"
    )
    # Fit the model using logistic regression
    model <- train(
      Species ~ ., 
      data = iris_binary, 
      method = "glm", 
      family = binomial(),
      trControl = train_control,
      metric = "ROC"
    )
    
    # manually Calculate AUC, by manually doing from saved predictions
    #auc_scores <- lapply(split(model$pred, model$pred$Resample), function(subset) {
    #  roc_response <- roc(subset$obs, subset$Positive)
    #  auc(roc_response)
    #})
    #mean(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
    #sd(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
    #hist(c(auc_scores$Fold1,auc_scores$Fold2,auc_scores$Fold3,auc_scores$Fold4,auc_scores$Fold5))
    
    # automatically access the results
    results <- model$results 
    results
    #mean_auc <- mean(results$ROC) #mean AUC
    #sd_auc <- sd(results$ROC) # SD AUC
    model$results$ROC #mean AUC
    model$results$ROCSD # SD AUC
    
  return(c(model$results$ROC,model$results$ROCSD)) # for single K-fold
}


#Gaussian Smoothing
Gaussian_Smoothing<-function(Incidence){
if (length(unique(Incidence))>1){
bandwidth <- 0.3*length(Incidence)  #1 Gaussian first-min+0: Adjust based on your data's trend scale #0.3- raw AUC 0.94 (0.93) L=20 ;  0.4- AUC 0.88; 0.5 AUC 0.87, 0.9 AUC 0.89, 1.5 raw AUC 0.9 (0.88
                                    #  Gaussian first+6: Adjust based on your data's trend scale #0.4- raw AUC 0.87;
                                    #  Gaussian after:   Adjust based on your data's trend scale #0.4- raw AUC 0.91 (0.87);   1.5 raw AUC 0.84
                                    #1 Gaussian after-min+0: Adjust based on your data's trend scale #0.4- raw AUC ; 0.3- raw AUC 0.91 (0.899) L=21;  0.6- raw AUC 0.86 (0.83); 1- raw AUC ; 
                                    #  Gaussian after-min+2: Adjust based on your data's trend scale #0.4- raw AUC 0.91 (0.87);
                                    #1 Gaussian after-min+6: Adjust based on your data's trend scale #0.4- raw AUC 0.92 (0.89); 0.3- raw AUC 0.94 (0.92); 
                                    #  Gaussian after-min+10: Adjust based on your data's trend scale #0.4- raw AUC 0.92 (0.87)
                                    #  Gaussian after-min+8: Adjust based on your data's trend scale #0.4- raw AUC 0.92 (0.88)
time=1:length(Incidence)
smoothed <- ksmooth(time, Incidence, kernel = "normal", bandwidth = bandwidth, n.points = length(Incidence) )
# Detrend by subtracting the smoothed trend
detrended <- Incidence - smoothed$y

# plus minimum to turn negative to positive
#detrended_new<-  detrended } else {detrended_new<-Incidence}
#detrended_new<-  detrended-min(detrended)+6 } else {detrended_new<-Incidence} #coss validation AUC>0.92
detrended_new<-  detrended-min(detrended)+10 } else {detrended_new<-Incidence}
return(detrended_new)
}
#plot(1:length(subs_data$Incidence), Gaussian_Smoothing(subs_data$Incidence) )
#plot(1:length(subs_data$Incidence), subs_data$Incidence )
#subs_data$date,incidenceData=as.data.frame(subs_data$Incidence)
#Incidence<-subs_data$Incidence
