
############# method 1, Fourier-transformed data 
#Transforming the original time series data to the frequency domain using the Fourier transform.
#Randomizing the phases of the Fourier-transformed data.
#Transforming back to the time domain to obtain a surrogate time series.
#Repeating steps 1-3 multiple times to generate a distribution of surrogate datasets.
#Comparing the statistic of interest (e.g., the Kendall rank correlation) calculated on the original data to the distribution obtained from the surrogate datasets.


Fourier_method<-function(number_surrogate, original_data) {
  library(tseries)
# Function to generate a surrogate dataset
generate_surrogate <- function(data) {
  n <- length(data)
  fft_data <- fft(data)
  # Generate random phases
  random_phases <- exp(1i * runif(n/2 - 1, -pi, pi))
  # Apply random phases
  fft_data[2:(n/2)] <- fft_data[2:(n/2)] * random_phases
  fft_data[(n/2 + 2):n] <- Conj(fft_data[2:(n/2)])
  # Inverse Fourier transform to get surrogate data
  surrogate_data <- Re(fft(fft_data, inverse = TRUE) / n)
  return(surrogate_data)
}

# Generate number of surrogate datasets
surrogate_stats <- numeric(number_surrogate)
set.seed(2)
for (i in 1:number_surrogate) {
  surrogate_data <- generate_surrogate(original_data)
  surrogate_stats[i] <- cor.test(1:length(surrogate_data), surrogate_data, method = "kendall")$estimate
}

# Calculate the Kendall rank correlation on the original data
original_stat <- cor.test(1:length(original_data), original_data, method = "kendall")$estimate

# Calculate the p-value
if(original_stat>=0) {p_value <- sum(surrogate_stats >= original_stat) / number_surrogate}
if(original_stat<0) {p_value <- sum(surrogate_stats <= original_stat) / number_surrogate}

return ( c(p_value, original_stat/abs(original_stat)) )

}  



### updated the Fourier_method transmofrmation
Fourier_method <- function(number_surrogate, original_data) {
  library(tseries)
  
  # Function to generate a surrogate dataset
  generate_surrogate <- function(data) {
    n <- length(data)
    fft_data <- fft(data)
    
    # Generate random phases
    if (n %% 2 == 0) {
      # Even length data
      random_phases <- exp(1i * runif(n/2 - 1, -pi, pi))
      fft_data[2:(n/2)] <- fft_data[2:(n/2)] * random_phases
      fft_data[(n/2 + 2):n] <- Conj(fft_data[(n/2):2])  # This maintains the conjugate symmetry
    } else {
      # Odd length data
      random_phases <- exp(1i * runif((n-1)/2, -pi, pi))
      fft_data[2:((n+1)/2)] <- fft_data[2:((n+1)/2)] * random_phases
      fft_data[((n+1)/2 + 1):n] <- Conj(fft_data[((n+1)/2):-1:2])
    }
    
    # Inverse Fourier transform to get surrogate data
    surrogate_data <- Re(fft(fft_data, inverse = TRUE) / n)
    return(surrogate_data)
  }
  
  # Generate the surrogates
  surrogates <- replicate(number_surrogate, generate_surrogate(original_data))
  
  # Generate number of surrogate datasets
  surrogate_stats <- numeric(number_surrogate)
  set.seed(2)
  for (i in 1:number_surrogate) {
    surrogate_data <- surrogates[,i]
    surrogate_stats[i] <- cor.test(1:length(surrogate_data), surrogate_data, method = "kendall")$estimate
  }
  
  # Calculate the Kendall rank correlation on the original data
  original_stat <- cor.test(1:length(original_data), original_data, method = "kendall")$estimate
  
  # Calculate the p-value
  if(original_stat>=0) {p_value <- sum(surrogate_stats >= original_stat) / number_surrogate}
  if(original_stat<0) {p_value <- sum(surrogate_stats <= original_stat) / number_surrogate}
  
  return ( c(p_value, original_stat/abs(original_stat)) )
}


# # example
# set.seed(123)
# original_data <- arima.sim(model = list(ar = 0.9), n = 50) # Generate some example time series data
# #plot(original_data, col="red", type="o")
# number_surrogate <- 100 # number of surrogates

#Fourier_method(number_surrogate, original_data)

#[1] 0.11 1.00 # 0.11 is p value; 1.00 means upward (-1 means downward)
#thus, insignificant upward.



############# method 2, Ebisuzaki (1997), Generate phase-randomized surrogate series as in Ebisuzaki (1997)
#number_surrogate=100
#original_data=AR1(new_data$Incidence,leng_window,1)
#original_data=no_outliers(new_data$Incidence,leng_window,1)
#original_data=Max_eigen(new_data$Incidence,leng_window,1)

Ebisuzaki_method<-function(number_surrogate, original_data) {

original_datass=original_data[!(is.na(original_data))] #NA remove

if( all(original_datass==0) || length(unique(original_datass))==1 ){tau_original=NA;p_value=NA;trendss=NA}
if( !(all(original_datass==0) || length(unique(original_datass))==1) ){
  if(length(original_datass)<2) {tau_original=NA;p_value=NA;trendss=NA }  
if(length(original_datass)>=2) { 
library(astrochron)
surrogates <- as.data.frame( matrix(nrow=length(original_datass)), ncol= number_surrogate)
set.seed(2)
for (i in 1:number_surrogate) {
  surrogates[,i] <- surrogates(original_datass, nsim=1, preserveMean=T, std=T, genplot=F, verbose=F)
}

#number_surrogate:Number of phase-randomized surrogate series to generate.
#preserveMean:Should surrogate series have the same mean value as data series? (T or F)
#std:Standardize results to guarantee equivalent variance as data series? (T or F)
#genplot:Generate summary plots? Only applies if nsim=1. (T or F)
#verbose:Verbose output? (T or F)

# calculate Kendall's tau for the original data
tau_original <- cor(1:length(original_datass),original_datass, method="kendall")
# calculate Kendall's tau for each surrogate
tau_surrogates <- apply(surrogates, 2, function(x) cor(1:length(original_datass), x, method="kendall"))
# calculate p-value

if(tau_original>=0) {p_value <- sum(tau_surrogates >= tau_original) / number_surrogate}
if(tau_original<0) {p_value <- sum(tau_surrogates <= tau_original) / number_surrogate}
trendss=tau_original/abs(tau_original)
}#if(length(original_datass)>=2)
}#if
return ( c(tau_original, p_value, trendss) )
}



#example data
# set.seed(123)
# original_data <- rnorm(1000)
# #plot(original_data, col="red", type="o")
# number_surrogate <- 100
# 
# Ebisuzaki_method(number_surrogate, original_data)
# #Ebisuzaki_method(number_surrogate, Ews)
# #[1] 0.32 1.00 # 0.32 is p value; 1.00 means upward (-1 means downward)
# #thus, insignificant upward.





#############Ebisuzaki (1997), Generate phase-randomized surrogate series as in Ebisuzaki (1997)
#original_data<-new_datas$Incidence
Ebisuzaki_method_multivariateTau<-function(number_surrogate, original_data) {
  
  original_datass=original_data[!(is.na(original_data))] #NA remove
  
  if( all(original_datass==0) || length(unique(original_datass))==1 ){tau_original=NA;p_value=NA;trendss=NA}
  if( !(all(original_datass==0) || length(unique(original_datass))==1) ){
    if(length(original_datass)<2) {tau_original=NA;p_value=NA;trendss=NA }  
    if(length(original_datass)>=2) { 
      library(astrochron)
      surrogates <- as.data.frame( matrix(nrow=length(original_datass)), ncol= number_surrogate)
      set.seed(2)
      for (i in 1:number_surrogate) {
        surrogates[,i] <- surrogates(original_datass, nsim=1, preserveMean=T, std=T, genplot=F, verbose=F)
      }
      
      #number_surrogate:Number of phase-randomized surrogate series to generate.
      #preserveMean:Should surrogate series have the same mean value as data series? (T or F)
      #std:Standardize results to guarantee equivalent variance as data series? (T or F)
      #genplot:Generate summary plots? Only applies if nsim=1. (T or F)
      #verbose:Verbose output? (T or F)

      
      
      if (status0=="top2"){mutiple_Ews_value<- cbind(1:length(CV(original_data,leng_window,1)),     CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1))
      }
      if (status0=="top3"){mutiple_Ews_value<- cbind(1:length(CV(original_data,leng_window,1)),     CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1),SD(original_data,leng_window,1))
      }
      if (status0=="top4"){mutiple_Ews_value<-  cbind(1:length(CV(original_data,leng_window,1)),    CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1),SD(original_data,leng_window,1),first_differenced_variance(original_data,leng_window,1))
      }
      if (status0=="top2_orthogonal"){mutiple_Ews_value<- cbind(1:length(CV(original_data,leng_window,1)),     CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1))
      }
      if (status0=="top3_orthogonal"){mutiple_Ews_value<- cbind(1:length(CV(original_data,leng_window,1)),     CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1),SD(original_data,leng_window,1))
      }
      if (status0=="top4_orthogonal"){mutiple_Ews_value<-  cbind(1:length(CV(original_data,leng_window,1)),   CV(original_data,leng_window,1), index_of_dispersion(original_data,leng_window,1),SD(original_data,leng_window,1),first_differenced_variance(original_data,leng_window,1))
      }
      # calculate Kendall's tau for the original data
      #tau_original <- cor(1:length(original_datass),original_datass, method="kendall")
      tau_original <- multivariate_kendall_tau(mutiple_Ews_value) 
      
      
      
      
      # calculate Kendall's tau for each surrogate
      tau_surrogates <- apply(surrogates, 2, function(x){
        if (status0=="top2"){mutiple_Ews_value_surrogates<- cbind(1:length(CV(x,leng_window,1)),   CV(x,leng_window,1), index_of_dispersion(x,leng_window,1))
        }
        if (status0=="top3"){mutiple_Ews_value_surrogates<- cbind(1:length(CV(x,leng_window,1)),   CV(x,leng_window,1), index_of_dispersion(x,leng_window,1),SD(x,leng_window,1))
        }
        if (status0=="top4"){mutiple_Ews_value_surrogates<-  cbind(1:length(CV(x,leng_window,1)),   CV(x,leng_window,1), index_of_dispersion(x,leng_window,1),SD(x,leng_window,1),first_differenced_variance(x,leng_window,1))
        }
        if (status0=="top2_orthogonal"){mutiple_Ews_value_surrogates<- cbind(1:length(CV(x,leng_window,1)),     CV(x,leng_window,1), index_of_dispersion(x,leng_window,1))
        }
        if (status0=="top3_orthogonal"){mutiple_Ews_value_surrogates<- cbind(1:length(CV(x,leng_window,1)),     CV(x,leng_window,1), index_of_dispersion(x,leng_window,1),SD(x,leng_window,1))
        }
        if (status0=="top4_orthogonal"){mutiple_Ews_value_surrogates<-  cbind(1:length(CV(x,leng_window,1)),    CV(x,leng_window,1), index_of_dispersion(x,leng_window,1),SD(x,leng_window,1),first_differenced_variance(x,leng_window,1))
        }
        tau_value<-multivariate_kendall_tau(mutiple_Ews_value_surrogates)
        return(tau_value )
      }
      )
      # calculate p-value
      
      if(tau_original>=0) {p_value <- sum(tau_surrogates[!is.na(tau_surrogates)] >= tau_original) / number_surrogate}
      if(tau_original<0) {p_value <- sum(tau_surrogates <= tau_original) / number_surrogate}
      trendss=tau_original/abs(tau_original)
    }#if(length(original_datass)>=2)
  }#if
  return ( c(tau_original, p_value, trendss) )
}






ken_p<-function(original_data) {
  taus=Ps=NA
  library(Kendall)
  original_data=original_data[!(is.na(original_data))]#remove na
  if (length(original_data)>=3)
    {
  #models<-cor.test(1:length(original_data), original_data, method="kendall")
  models<-Kendall(1:length(original_data), original_data)
  #return(c(as.numeric(models$estimate),as.numeric(models$p.value)))
  taus=as.numeric(models$tau)
  Ps=as.numeric(models$sl)
  }
  
  return(c(taus,Ps))
}



#ken_p(AR1_a)[2]
#rep(ken_p(AR1_a),length(AR1_a))
#as.data.frame(t(matrix(rep(ken_p(AR1_a), each = 5), nrow = 2)))    
