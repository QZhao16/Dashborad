# Function to find consecutive integers
find_consecutive <- function(series) {
  consecutive <- list()
  current_sequence <- c(series[1])
  i=2
  for (i in 2:length(series)) {
    if (series[i] == series[i-1] + 1) {
      current_sequence <- c(current_sequence, series[i])
    } else {
      if (length(current_sequence) > 1) {
        consecutive[[length(consecutive) + 1]] <- current_sequence
      }
      current_sequence <- series[i]
    }
  }
  if (length(current_sequence) > 1) {
    consecutive[[length(consecutive) + 1]] <- current_sequence
  }
  return(consecutive)
}

# Example series of integers
series <- c(1, 2, 3, 7,8,9)
consecutive_groups <- find_consecutive(series)




# Function to find consecutive days
find_consecutiveDays <- function(series) {
  consecutive <- list()
  current_sequence <- c(series[1])
  i=2
  for (i in 2:length(series)) {
    if (series[i] == series[i-1] + 1) {
      current_sequence <- c(current_sequence, series[i])
    } else {
      if (length(current_sequence) > 1) {
        consecutive[[length(consecutive) + 1]] <- current_sequence
      }
      current_sequence <- series[i]
    }
  }
  if (length(current_sequence) > 1) {
    consecutive[[length(consecutive) + 1]] <- current_sequence
  }
  return(consecutive)
}

# Example series of date
series <- as.Date("2015-10-01") + c(0:2,60, 71:72)
consecutive_groups <- find_consecutiveDays(series)



# Function to find consecutive days
find_consecutiveDay <- function(series) {
  consecutive <- list()
  
  if (length(series)>=2){
    
  current_sequence <- c(series[1])
  for (i in 2:length(series)) {
    if (series[i] == series[i-1] + 1) {
      current_sequence <- c(current_sequence, series[i])
    } else {
      if (length(current_sequence) > 1) {
        consecutive[[length(consecutive) + 1]] <- current_sequence
      }
      current_sequence <- series[i]
    }
  }
  if (length(current_sequence) > 1) {
    consecutive[[length(consecutive) + 1]] <- current_sequence
  }
  }#if (length(consecutive)>=1)
  return(consecutive)
}

# Example series of date
series <- as.Date("2015-10-01") + c(0:2,60, 71:72)
consecutive_groups <- find_consecutiveDay(series)


# Function to find consecutive days
find_consecutiveFirstDay <- function(series) {
  consecutive <- list()
  
  if (length(series)>=2){
    
    current_sequence <- c(series[1])
    for (i in 2:length(series)) {
      if (series[i] == series[i-1] + 1) {
        current_sequence <- c(current_sequence, series[i])
      } else {
        if (length(current_sequence) > 1) {
          consecutive[[length(consecutive) + 1]] <- current_sequence
        }
        current_sequence <- series[i]
      }
    }
    if (length(current_sequence) > 1) {
      consecutive[[length(consecutive) + 1]] <- current_sequence
    }
  }#if (length(consecutive)>=1)
  
  #return(consecutive)
  
  
  # return first in each list
  consecutive_2=NULL
  if (length(consecutive)>0){
    a=1
    for (a in 1:length(consecutive)){
      consecutive_2=cbind(consecutive_2, as.character(consecutive[[a]][1]) )
    }
  }
  return(as.Date(consecutive_2,"%Y-%m-%d"))
}



# Example series of date
series <- as.Date("2015-10-01") + c(0:2,60, 71:72)
consecutive_groups <- find_consecutiveFirstDay(series)




# Function to find consecutive days
find_two_aWeek <- function(series) {
  consecutive <- list()
  
  if (length(series)>=2){
    
    current_sequence <- c(series[1])
    for (i in 2:length(series)) {
      if (series[i] <= series[i-1] + 6) {
        current_sequence <- c(current_sequence, series[i])
      } else {
        if (length(current_sequence) > 1) {
          consecutive[[length(consecutive) + 1]] <- current_sequence
        }
        current_sequence <- series[i]
      }
    }
    if (length(current_sequence) > 1) {
      consecutive[[length(consecutive) + 1]] <- current_sequence
    }
  }#if (length(consecutive)>=1)
  
  
  #return(consecutive)
  # return first in each list
  consecutive_2=NULL
  if (length(consecutive)>0){
    a=1
    for (a in 1:length(consecutive)){
      consecutive_2=cbind(consecutive_2, as.character(consecutive[[a]][1]) )
    }
  }
  return(as.Date(consecutive_2,"%Y-%m-%d"))
}

# Example series of date
series <- as.Date("2015-10-01") + c(0:2,5:7,30, 71:77)
consecutive_groups <- find_two_aWeek(series)


