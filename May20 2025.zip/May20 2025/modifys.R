modifys=function (data){
  unique(data$EWs)
  data1=data %>% filter(EWs=="AR1") %>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data1)=(c("Tau_AR1","P_AR1","outbreaks"))
  data2=data %>% filter(EWs=="AR2")%>% select(c("Tau_original","P_value","outbreaks"))
  colnames(data2)=(c("Tau_AR2","P_AR2","outbreaks"))
  data3=data %>% filter(EWs=="AR3")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data3)=(c("Tau_AR3","P_AR3","outbreaks"))
  data4=data %>% filter(EWs=="SD")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data4)=(c("Tau_SD","P_SD","outbreaks"))
  data5=data %>% filter(EWs=="Skewness")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data5)=(c("Tau_Skewness","P_Skewness","outbreaks"))
  
  data6=data %>% filter(EWs=="Kurtosis")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data6)=(c("Tau_Kurtosis","P_Kurtosis","outbreaks"))
  data7=data %>% filter(EWs=="CV")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data7)=(c("Tau_CV","P_CV","outbreaks"))
  data8=data %>% filter(EWs=="first_differenced_variance")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data8)=(c("Tau_first_differenced_variance","P_first_differenced_variance","outbreaks"))
  data9=data %>% filter(EWs=="Autocovariance")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data9)=(c("Tau_Autocovariance","P_Autocovariance","outbreaks"))
  data10=data %>% filter(EWs=="index_of_dispersion")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data10)=(c("Tau_index_of_dispersion","P_index_of_dispersion","outbreaks"))
  
  data11=data %>% filter(EWs=="density_ratio")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data11)=(c("Tau_density_ratio","P_density_ratio","outbreaks"))
  
  data12=data %>% filter(EWs=="relative_dispersions")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data12)=(c("Tau_relative_dispersions","P_relative_dispersions","outbreaks"))
  
  data13=data %>% filter(EWs=="Hurst_exponents")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data13)=(c("Tau_Hurst_exponents","P_Hurst_exponents","outbreaks"))
  
  data14=data %>% filter(EWs=="time_series_acceleration")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data14)=(c("Tau_time_series_acceleration","P_time_series_acceleration","outbreaks"))
  
  #data15=data %>% filter(EWs=="Slopes")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data15)=(c("Tau_Slopes","P_Slopes","outbreaks"))
  
  data16=data %>% filter(EWs=="no_outliers")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data16)=(c("Tau_no_outliers","P_no_outliers","outbreaks"))
  
  #data17=data %>% filter(EWs=="Step_changes")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data17)=(c("Tau_Step_changes","P_Step_changes","outbreaks"))
  
  #data18=data %>% filter(EWs=="N_peaks")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data18)=(c("Tau_N_peaks","P_N_peaks","outbreaks"))
  
  data19=data %>% filter(EWs=="Turning_Points")%>% select(c("Tau_original","P_value","outbreaks"))
  colnames(data19)=(c("Tau_Turning_Points","P_Turning_Points","outbreaks"))
  
  #data20=data %>% filter(EWs=="FFT_AMP")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data20)=(c("Tau_FFT_AMP","P_FFT_AMP","outbreaks"))
  
  #data21=data %>% filter(EWs=="poincare_variabilitys")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data21)=(c("Tau_poincare_variabilitys","P_poincare_variabilitys","outbreaks"))
  
  finals=as.data.frame( cbind(data1[,c("outbreaks","Tau_AR1","P_AR1")], data2[,c(1,2)] , 
                              #data3[,c(1,2)], 
                              data4[,c(1,2)], data5[,c(1,2)],
        data6[,c(1,2)] , data7[,c(1,2)], data8[,c(1,2)], data9[,c(1,2)], data10[,c(1,2)],
        
        data11[,c(1,2)] , data12[,c(1,2)], data13[,c(1,2)], data14[,c(1,2)], 
        #data15[,c(1,2)],
        data16[,c(1,2)] , 
        #data17[,c(1,2)], 
        #data18[,c(1,2)], 
        data19[,c(1,2)]
        #data20[,c(1,2)],
        #data21[,c(1,2)] 
        ))
  
  return(finals)
}



modifys_2=function (data){
  unique(data$EWs)
  data1=data %>% filter(EWs=="AR1") %>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data1)=(c("Tau_AR1","P_AR1","outbreaks"))
  #data2=data %>% filter(EWs=="AR2")%>% select(c("Tau_original","P_value","outbreaks"))
  #colnames(data2)=(c("Tau_AR2","P_AR2","outbreaks"))
  #data3=data %>% filter(EWs=="AR3")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data3)=(c("Tau_AR3","P_AR3","outbreaks"))
  data4=data %>% filter(EWs=="SD")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data4)=(c("Tau_SD","P_SD","outbreaks"))
  data5=data %>% filter(EWs=="Skewness")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data5)=(c("Tau_Skewness","P_Skewness","outbreaks"))
  
  data6=data %>% filter(EWs=="Kurtosis")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data6)=(c("Tau_Kurtosis","P_Kurtosis","outbreaks"))
  data7=data %>% filter(EWs=="CV")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data7)=(c("Tau_CV","P_CV","outbreaks"))
  data8=data %>% filter(EWs=="first_differenced_variance")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data8)=(c("Tau_first_differenced_variance","P_first_differenced_variance","outbreaks"))
  data9=data %>% filter(EWs=="Autocovariance")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data9)=(c("Tau_Autocovariance","P_Autocovariance","outbreaks"))
  data10=data %>% filter(EWs=="index_of_dispersion")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data10)=(c("Tau_index_of_dispersion","P_index_of_dispersion","outbreaks"))
  
  data11=data %>% filter(EWs=="density_ratio")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data11)=(c("Tau_density_ratio","P_density_ratio","outbreaks"))
  
  data12=data %>% filter(EWs=="relative_dispersions")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data12)=(c("Tau_relative_dispersions","P_relative_dispersions","outbreaks"))
  
  data13=data %>% filter(EWs=="Hurst_exponents")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data13)=(c("Tau_Hurst_exponents","P_Hurst_exponents","outbreaks"))
  
  data14=data %>% filter(EWs=="time_series_acceleration")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data14)=(c("Tau_time_series_acceleration","P_time_series_acceleration","outbreaks"))
  
  #data15=data %>% filter(EWs=="Slopes")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data15)=(c("Tau_Slopes","P_Slopes","outbreaks"))
  
  data16=data %>% filter(EWs=="no_outliers")%>% select(c("Tau_original","P_value","outbreaks")) 
  colnames(data16)=(c("Tau_no_outliers","P_no_outliers","outbreaks"))
  
  #data17=data %>% filter(EWs=="Step_changes")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data17)=(c("Tau_Step_changes","P_Step_changes","outbreaks"))
  
  #data18=data %>% filter(EWs=="N_peaks")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data18)=(c("Tau_N_peaks","P_N_peaks","outbreaks"))
  
  data19=data %>% filter(EWs=="Turning_Points")%>% select(c("Tau_original","P_value","outbreaks"))
  colnames(data19)=(c("Tau_Turning_Points","P_Turning_Points","outbreaks"))
  
  #data20=data %>% filter(EWs=="FFT_AMP")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data20)=(c("Tau_FFT_AMP","P_FFT_AMP","outbreaks"))
  
  #data21=data %>% filter(EWs=="poincare_variabilitys")%>% select(c("Tau_original","P_value","outbreaks")) 
  #colnames(data21)=(c("Tau_poincare_variabilitys","P_poincare_variabilitys","outbreaks"))
  
  finals=as.data.frame( cbind(data1[,c("outbreaks","Tau_AR1","P_AR1")], 
                              #data2[,c(1,2)] , 
                              #data3[,c(1,2)], 
                              data4[,c(1,2)], data5[,c(1,2)],
                              data6[,c(1,2)] , data7[,c(1,2)], data8[,c(1,2)], data9[,c(1,2)], data10[,c(1,2)],
                              
                              data11[,c(1,2)] , data12[,c(1,2)], data13[,c(1,2)], data14[,c(1,2)], 
                              #data15[,c(1,2)],
                              data16[,c(1,2)] , 
                              #data17[,c(1,2)], 
                              #data18[,c(1,2)], 
                              data19[,c(1,2)]
                              #data20[,c(1,2)],
                              #data21[,c(1,2)] 
  ))
  
  return(finals)
}





na_removeal=function(data) {
  for (i in 2:ncol(data)){
    data=data[!is.na(data[,i]),]
  }
  return(data)
}




