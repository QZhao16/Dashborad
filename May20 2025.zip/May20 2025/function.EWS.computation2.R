### Part 1 EWs over trend (downward upward)
EWs_do2<-function (new_datas,leng_window,Yes_No,the_outbreak){
  Yes_No=Yes_No
  situations<-the_outbreak
  replicate_number=1
  
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          
                          c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          #c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          #c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          #c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          #c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys"),
                          
                          c(Ebisuzaki_method(number,wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_filtering"),
                          c(Ebisuzaki_method(number,wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_reddening")
                          )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
  } # if
  
  
} # function EWs_do



### Part 1 EWs over trend (downward upward)
EWs_do<-function (new_datas,leng_window,Yes_No){
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-"No";replicate_number=t_total}
  
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          
                          c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          #c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          #c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          #c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          #c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys"),
                          
                          c(Ebisuzaki_method(number,wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_filtering"),
                          c(Ebisuzaki_method(number,wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_reddening")
    )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
    
    #return(final_results_2)
  } # if
  
  return(final_results_2)
  
} # function EWs_do


### Part 1 EWs over trend (downward upward)
EWs_do3<-function (new_datas,leng_window,Yes_No){
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-"No";replicate_number=t_total}

  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(rep(NA,3),"AR1"),
                          c(rep(NA,3),"AR2"),
                          c(rep(NA,3),"AR3"),
                          c(rep(NA,3),"SD"),
                          c(rep(NA,3),"Skewness"),
                          c(rep(NA,3),"Kurtosis"),
                          c(rep(NA,3),"CV"),
                          c(rep(NA,3),"first_differenced_variance"),
                          c(rep(NA,3),"Autocovariance"),
                          c(rep(NA,3),"index_of_dispersion"),
                          c(rep(NA,3),"density_ratio"),
                          
                          c(rep(NA,3),"Max_eigen"),
                          
                          #vest function
                          c(rep(NA,3),"relative_dispersions"),
                          #c(rep(NA,3),"max_lyapunov_exps"),
                          c(rep(NA,3),"Hurst_exponents"),
                          c(rep(NA,3),"time_series_acceleration"),
                          #c(rep(NA,3),"Slopes"),
                          #c(rep(NA,3),"Daubechies_DWT"),
                          c(rep(NA,3),"no_outliers"),
                          #c(rep(NA,3),"Step_changes"),
                          c(rep(NA,3),"N_peaks"),
                          c(rep(NA,3),"Turning_Points"),
                          #c(rep(NA,3),"FFT_AMP"),
                          #c(rep(NA,3),"poincare_variabilitys") 
                          c(rep(NA,3),"wavelet_filtering"),
                          c(rep(NA,3),"wavelet_reddening")
                          )
    
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
  
  
  }else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          
                          c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          #c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          #c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          #c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          #c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys")
                          
                          c(Ebisuzaki_method(number,wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_filtering"),
                          c(Ebisuzaki_method(number,wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)),"wavelet_reddening")
                          )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
    
    
  } # if
  
  return(final_results_2)
} # function EWs_do


### Part 1 EWs over trend (downward upward)
EWs_do3_multivariate_tau<-function (new_datas,leng_window,Yes_No){
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(c(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(c(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-"No";replicate_number=t_total}
  
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(rep(NA,3),"multivariate_tau")
    )
    
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
    
    
  }else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    
    # if (status0=="top2"){mutiple_Ews_value<- cbind(1:length(CV(new_datas$Incidence,leng_window,1)),     CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1))
    # }
    # if (status0=="top3"){mutiple_Ews_value<- cbind(1:length(CV(new_datas$Incidence,leng_window,1)),   CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1),SD(new_datas$Incidence,leng_window,1))
    # }
    # if (status0=="top4"){mutiple_Ews_value<-  cbind(1:length(CV(new_datas$Incidence,leng_window,1)),   CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1),SD(new_datas$Incidence,leng_window,1),first_differenced_variance(new_datas$Incidence,leng_window,1))
    # }
    # if (status0=="top2_orthogonal"){mutiple_Ews_value<- cbind(1:length(CV(new_datas$Incidence,leng_window,1)),     CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1))
    # }
    # if (status0=="top3_orthogonal"){mutiple_Ews_value<- cbind(1:length(CV(new_datas$Incidence,leng_window,1)),   CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1),SD(new_datas$Incidence,leng_window,1))
    # }
    # if (status0=="top4_orthogonal"){mutiple_Ews_value<-  cbind(1:length(CV(new_datas$Incidence,leng_window,1)),   CV(new_datas$Incidence,leng_window,1), index_of_dispersion(new_datas$Incidence,leng_window,1),SD(new_datas$Incidence,leng_window,1),first_differenced_variance(new_datas$Incidence,leng_window,1))
    # }
    
    
    final_results_2=rbind(c(Ebisuzaki_method_multivariateTau(number,new_datas$Incidence),paste0(status0) )
    )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number","Yes_No") #1 upward; -1 downward
    final_results_2
    
    
  } # if
  
  return(final_results_2)
} # function EWs_do




############## Part 2
#2.1 temperature mean over moving window
temperature_mean <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  temperatures <-NULL
  for(j in window_indices) {
    temperatures <- c(temperatures, mean(inciddences[(j-window_size+1):j], na.rm=TRUE) )    
  }
  return(temperatures)
}


# time in Risk model
#time=new_datas$date
#leng_window=5
#steps=1
#time_seg(new_datas$date,leng_window,1)
time_seg <- function (time, leng_window, steps=1){    
  window_end <- time[ seq(leng_window, length(time), steps) ]            #cutting data into rolling windows
  window_start <- time[ seq(leng_window, length(time), steps)-(leng_window) +1 ]
  return( cbind( as.character(as.Date(window_start,"%Y-%m-%d")),   as.character(as.Date(window_end,"%Y-%m-%d")) ) )
}



#new_datas<-as.data.frame( rbind(subs_data_31,subs_data_31,subs_data_31,subs_data_31,subs_data_31) )
## EWs over moving window, after sep-15 2024
EWs_do_TimeSeries<-function (new_datas,leng_window,Yes_No){
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(cbind(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(cbind(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  #
  risk_model<-function(situations,lengthss,position) {
    if(situations=='No'){returns=rep(0,lengthss)}
    
    if(situations=='Yes'){
    if(lengthss==position | lengthss<position){returns=rep(0,lengthss);
    returns[lengthss]=1}                                                          #significant point as 1 in risk model
    if(lengthss>position ){returns=rep(0,lengthss);
      returns[1:(lengthss-position-1)]=0;returns[(lengthss-position):lengthss]=1} #significant point as 1 in risk model
    }
    return(returns)
  }
  
  risk2_model<-function(situations,lengthss,position) {
    if(situations=='No'){returns=rep(0,lengthss)}
    if(situations=='Yes'){returns=rep(0,lengthss);returns[lengthss]=1} #Always the last point as 1 in risk model
    return(returns)
  }
  
  
  #
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    
    # tau time series
    AR1_a=AR1(new_data$Incidence,leng_window,1)
    AR2_a=AR2(new_data$Incidence,leng_window,1)
    AR3_a=AR3(new_data$Incidence,leng_window,1)
    SD_a=SD(new_data$Incidence,leng_window,1)
    Skewness_a=Skewness(new_data$Incidence,leng_window,1)
    Kurtosis_a=Kurtosis(new_data$Incidence,leng_window,1)
    CV_a=CV(new_data$Incidence,leng_window,1)
    first_differenced_variance_a=first_differenced_variance(new_data$Incidence,leng_window,1)
    Autocovariance_a=Autocovariance(new_data$Incidence,leng_window,1)
    index_of_dispersion_a=index_of_dispersion(new_data$Incidence,leng_window,1)
    density_ratio_a=density_ratio(new_data$Incidence,leng_window,1)
    
    relative_dispersions_a=relative_dispersions(new_data$Incidence,leng_window,1)
    Hurst_exponents_a=Hurst_exponents(new_data$Incidence,leng_window,1)
    time_series_acceleration_a=time_series_acceleration(new_data$Incidence,leng_window,1)
    #Slopes_a=Slopes(new_data$Incidence,leng_window,1)
    no_outliers_a=no_outliers(new_data$Incidence,leng_window,1)
    #Step_changes_a=Step_changes(new_data$Incidence,leng_window,1)
    #N_peaks_a=N_peaks(new_data$Incidence,leng_window,1)
    Turning_Points_a=Turning_Points(new_data$Incidence,leng_window,1)
    #FFT_AMP_a=FFT_AMP(new_data$Incidence,leng_window,1)
    #poincare_variabilitys_a=poincare_variabilitys(new_data$Incidence,leng_window,1)
    Max_eigen_a=Max_eigen(new_data$Incidence,leng_window,1)
    wavelet_filterings_a=wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)
    wavelet_reddenings_a=wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)
    
    # risk model
    risk_AR1=risk_model(situations,length(AR1_a),response_time(AR1_a,new_data))
    risk_AR2=risk_model(situations,length(AR2_a),response_time(AR2_a,new_data))
    risk_AR3=risk_model(situations,length(AR3_a),response_time(AR3_a,new_data))
    risk_SD=risk_model(situations,length(SD_a),response_time(SD_a,new_data))
    risk_Skewness=risk_model(situations,length(Skewness_a),response_time(Skewness_a,new_data))
    risk_Kurtosis=risk_model(situations,length(Kurtosis_a),response_time(Kurtosis_a,new_data))
    risk_CV=risk_model(situations,length(CV_a),response_time(CV_a,new_data))
    risk_first_differenced_variance=risk_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a,new_data))
    risk_Autocovariance=risk_model(situations,length(Autocovariance_a),response_time(Autocovariance_a,new_data))
    risk_index_of_dispersion=risk_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a,new_data))
    risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
    risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
    risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
    
    risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
    risk_Hurst_exponents=risk_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a,new_data))
    risk_time_series_acceleration=risk_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a,new_data))
    #risk_Slopes=risk_model(situations,length(Slopes_a),response_time(Slopes_a))
    risk_no_outliers=risk_model(situations,length(no_outliers_a),response_time(no_outliers_a,new_data))
    #risk_Step_changes=risk_model(situations,length(Step_changes_a),response_time(Step_changes_a))
    #risk_N_peaks=risk_model(situations,length(N_peaks_a),response_time(N_peaks_a))
    risk_Turning_Points=risk_model(situations,length(Turning_Points_a),response_time(Turning_Points_a,new_data))
    #risk_FFT_AMP=risk_model(situations,length(FFT_AMP_a),response_time(FFT_AMP_a))
    #risk_poincare_variabilitys=risk_model(situations,length(poincare_variabilitys_a),response_time(poincare_variabilitys_a))
    risk_Max_eigen=risk_model(situations,length(Max_eigen_a),response_time(Max_eigen_a,new_data))
    risk_wavelet_filtering=risk_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a,new_data))
    risk_wavelet_reddening=risk_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a,new_data))
    
    # risk model2
    risk2_AR1=risk2_model(situations,length(AR1_a),response_time(AR1_a,new_data))
    risk2_AR2=risk2_model(situations,length(AR2_a),response_time(AR2_a,new_data,new_data))
    risk2_AR3=risk2_model(situations,length(AR3_a),response_time(AR3_a,new_data))
    risk2_SD=risk2_model(situations,length(SD_a),response_time(SD_a,new_data))
    risk2_Skewness=risk2_model(situations,length(Skewness_a),response_time(Skewness_a,new_data))
    risk2_Kurtosis=risk2_model(situations,length(Kurtosis_a),response_time(Kurtosis_a,new_data))
    risk2_CV=risk2_model(situations,length(CV_a),response_time(CV_a,new_data))
    risk2_first_differenced_variance=risk2_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a,new_data))
    risk2_Autocovariance=risk2_model(situations,length(Autocovariance_a),response_time(Autocovariance_a,new_data))
    risk2_index_of_dispersion=risk2_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a,new_data))
    risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
    risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
    risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a,new_data))
    
    risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a,new_data))
    risk2_Hurst_exponents=risk2_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a,new_data))
    risk2_time_series_acceleration=risk2_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a,new_data))
    #risk2_Slopes=risk2_model(situations,length(Slopes_a),response_time(Slopes_a))
    risk2_no_outliers=risk2_model(situations,length(no_outliers_a),response_time(no_outliers_a,new_data))
    # risk2_Step_changes=risk2_model(situations,length(Step_changes_a),response_time(Step_changes_a))
    #risk2_N_peaks=risk2_model(situations,length(N_peaks_a),response_time(N_peaks_a))
    risk2_Turning_Points=risk2_model(situations,length(Turning_Points_a),response_time(Turning_Points_a,new_data))
    #risk2_FFT_AMP=risk2_model(situations,length(FFT_AMP_a),response_time(FFT_AMP_a))
    #risk2_poincare_variabilitys=risk2_model(situations,length(poincare_variabilitys_a),response_time(poincare_variabilitys_a))
    risk2_Max_eigen=risk2_model(situations,length(Max_eigen_a),response_time(Max_eigen_a,new_data))
    risk2_wavelet_filterings=risk2_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a,new_data))
    risk2_wavelet_reddenings=risk2_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a,new_data))
    
    final_results_2=rbind(
      cbind(seq(1,length(AR1_a),by=1), AR1_a,rep(ken_p(AR1_a)[1],length(AR1_a)), rep(ken_p(AR1_a)[2],length(AR1_a)), temperature_mean(TAVG,leng_window,1)[length(AR1_a)],risk_AR1,risk2_AR1, time_seg(new_data$date,leng_window,1), rep("AR1",length(AR1_a))),
      cbind(seq(1,length(AR2_a),by=1), AR2_a,rep(ken_p(AR2_a)[1],length(AR2_a)), rep(ken_p(AR2_a)[2],length(AR2_a)), temperature_mean(TAVG,leng_window,1)[length(AR2_a)],risk_AR2,risk2_AR2, time_seg(new_data$date,leng_window,1),rep("AR2",length(AR2_a))),
      cbind(seq(1,length(AR3_a),by=1), AR3_a,rep(ken_p(AR3_a)[1],length(AR3_a)), rep(ken_p(AR3_a)[2],length(AR3_a)), temperature_mean(TAVG,leng_window,1)[length(AR3_a)],risk_AR3,risk2_AR3,time_seg(new_data$date,leng_window,1), rep("AR3",length(AR3_a))),
      cbind(seq(1,length(SD_a),by=1), SD_a,rep(ken_p(SD_a)[1],length(SD_a)), rep(ken_p(SD_a)[2],length(SD_a)), temperature_mean(TAVG,leng_window,1)[length(SD_a)],risk_SD,risk2_SD,time_seg(new_data$date,leng_window,1), rep("SD",length(SD_a))),
      cbind(seq(1,length(Skewness_a),by=1), Skewness_a,rep(ken_p(Skewness_a)[1],length(Skewness_a)), rep(ken_p(Skewness_a)[2],length(Skewness_a)), temperature_mean(TAVG,leng_window,1)[length(Skewness_a)],risk_Skewness,risk2_Skewness,time_seg(new_data$date,leng_window,1), rep("Skewness",length(Skewness_a))),
      cbind(seq(1,length(Kurtosis_a),by=1), Kurtosis_a,rep(ken_p(Kurtosis_a)[1],length(Kurtosis_a)), rep(ken_p(Kurtosis_a)[2],length(Kurtosis_a)), temperature_mean(TAVG,leng_window,1)[length(Kurtosis_a)],risk_Kurtosis,risk2_Kurtosis,time_seg(new_data$date,leng_window,1), rep("Kurtosis",length(Kurtosis_a))),
      cbind(seq(1,length(CV_a),by=1), CV_a,rep(ken_p(CV_a)[1],length(CV_a)), rep(ken_p(CV_a)[2],length(CV_a)), temperature_mean(TAVG,leng_window,1)[length(CV_a)],risk_CV,risk2_CV,time_seg(new_data$date,leng_window,1), rep("CV",length(CV_a))),
      cbind(seq(1,length(first_differenced_variance_a),by=1), first_differenced_variance_a,rep(ken_p(first_differenced_variance_a)[1],length(first_differenced_variance_a)), rep(ken_p(first_differenced_variance_a)[2],length(first_differenced_variance_a)), temperature_mean(TAVG,leng_window,1)[length(first_differenced_variance_a)],risk_first_differenced_variance,risk2_first_differenced_variance,time_seg(new_data$date,leng_window,1), rep("first_differenced_variance",length(first_differenced_variance_a))),
      cbind(seq(1,length(Autocovariance_a),by=1), Autocovariance_a,rep(ken_p(Autocovariance_a)[1],length(Autocovariance_a)), rep(ken_p(Autocovariance_a)[2],length(Autocovariance_a)), temperature_mean(TAVG,leng_window,1)[length(Autocovariance_a)],risk_Autocovariance,risk2_Autocovariance,time_seg(new_data$date,leng_window,1), rep("Autocovariance",length(Autocovariance_a))),
      cbind(seq(1,length(index_of_dispersion_a),by=1), index_of_dispersion_a,rep(ken_p(index_of_dispersion_a)[1],length(index_of_dispersion_a)), rep(ken_p(index_of_dispersion_a)[2],length(index_of_dispersion_a)), temperature_mean(TAVG,leng_window,1)[length(index_of_dispersion_a)],risk_index_of_dispersion,risk2_index_of_dispersion,time_seg(new_data$date,leng_window,1), rep("index_of_dispersion",length(index_of_dispersion_a))),
      cbind(seq(1,length(density_ratio_a),by=1), density_ratio_a,rep(ken_p(density_ratio_a)[1],length(density_ratio_a)), rep(ken_p(density_ratio_a)[2],length(density_ratio_a)), temperature_mean(TAVG,leng_window,1)[length(density_ratio_a)],risk_density_ratio,risk2_density_ratio,time_seg(new_data$date,leng_window,1), rep("density_ratio",length(density_ratio_a))),
      #cbind(Max_eigen_a,temperature_mean(TAVG,leng_window,1)[length(AR2_a)],rep("Max_eigen",length(Max_eigen_a))),
      #vest function
      cbind(seq(1,length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))]),by=1), relative_dispersions_a[!(is.infinite(relative_dispersions_a))],rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[1],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[2],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), 
            temperature_mean(TAVG[1:nrow(new_data)],leng_window,1)[!(is.infinite(relative_dispersions_a))], 
            risk_relative_dispersions[!(is.infinite(relative_dispersions_a))],
            risk2_relative_dispersions[!(is.infinite(relative_dispersions_a))],
            time_seg(new_data$date,leng_window,1)[!(is.infinite(relative_dispersions_a)),],
            rep("relative_dispersions",length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))]))),
      #cbind(max_lyapunov_exps_a,"max_lyapunov_exps",length(max_lyapunov_exps_a))),
      cbind(seq(1,length(Hurst_exponents_a),by=1), Hurst_exponents_a,rep(ken_p(Hurst_exponents_a)[1],length(Hurst_exponents_a)), rep(ken_p(Hurst_exponents_a)[2],length(Hurst_exponents_a)), temperature_mean(TAVG,leng_window,1)[length(Hurst_exponents_a)],risk_Hurst_exponents,risk2_Hurst_exponents,time_seg(new_data$date,leng_window,1), rep("Hurst_exponents",length(Hurst_exponents_a))),
      cbind(seq(1,length(time_series_acceleration_a),by=1), time_series_acceleration_a,rep(ken_p(time_series_acceleration_a)[1],length(time_series_acceleration_a)), rep(ken_p(time_series_acceleration_a)[2],length(time_series_acceleration_a)), 
            temperature_mean(TAVG,leng_window,1)[length(time_series_acceleration_a)],
            risk_time_series_acceleration,
            risk2_time_series_acceleration,
            time_seg(new_data$date,leng_window,1), 
            rep("time_series_acceleration",length(time_series_acceleration_a))),
      #cbind(Slopes_a,rep(ken_p(Slopes_a)[1],length(Slopes_a)), rep(ken_p(Slopes_a)[2],length(Slopes_a)), temperature_mean(TAVG,leng_window,1)[length(Slopes_a)],risk_Slopes,risk2_Slopes,time_seg(new_data$date,leng_window,1), rep("Slopes",length(Slopes_a))),
      #cbind(Daubechies_DWT_a,temperature_mean(TAVG,leng_window,1)[length(Daubechies_DWT_a)],risk_AR1, rep("Daubechies_DWT",length(Daubechies_DWT_a))),
      cbind(seq(1,length(no_outliers_a),by=1), no_outliers_a,rep(ken_p(no_outliers_a)[1],length(no_outliers_a)), rep(ken_p(no_outliers_a)[2],length(no_outliers_a)), temperature_mean(TAVG,leng_window,1)[length(no_outliers_a)],risk_no_outliers,risk2_no_outliers,time_seg(new_data$date,leng_window,1), rep("no_outliers",length(no_outliers_a))),
      #cbind(Step_changes_a,rep(ken_p(Step_changes_a)[1],length(Step_changes_a)), rep(ken_p(Step_changes_a)[2],length(Step_changes_a)), temperature_mean(TAVG,leng_window,1)[length(Step_changes_a)],risk_Step_changes,risk2_Step_changes,time_seg(new_data$date,leng_window,1), rep("Step_changes",length(Step_changes_a))),
      #cbind(N_peaks_a,rep(ken_p(N_peaks_a)[1],length(N_peaks_a)), rep(ken_p(N_peaks_a)[2],length(N_peaks_a)), temperature_mean(TAVG,leng_window,1)[length(N_peaks_a)],risk_N_peaks,risk2_N_peaks,time_seg(new_data$date,leng_window,1), rep("N_peaks",length(N_peaks_a))),
      cbind(seq(1,length(Turning_Points_a),by=1), Turning_Points_a,rep(ken_p(Turning_Points_a)[1],length(Turning_Points_a)), rep(ken_p(Turning_Points_a)[2],length(Turning_Points_a)), temperature_mean(TAVG,leng_window,1)[length(Turning_Points_a)],risk_Turning_Points,risk2_Turning_Points,time_seg(new_data$date,leng_window,1), rep("Turning_Points",length(Turning_Points_a))),
      #cbind(FFT_AMP_a,rep(ken_p(FFT_AMP_a)[1],length(FFT_AMP_a)), rep(ken_p(FFT_AMP_a)[2],length(FFT_AMP_a)), temperature_mean(TAVG,leng_window,1)[length(FFT_AMP_a)],risk_FFT_AMP,risk2_FFT_AMP, time_seg(new_data$date,leng_window,1),rep("FFT_AMP",length(FFT_AMP_a))),
      #cbind(poincare_variabilitys_a,rep(ken_p(poincare_variabilitys_a)[1],length(poincare_variabilitys_a)), rep(ken_p(poincare_variabilitys_a)[2],length(poincare_variabilitys_a)), temperature_mean(TAVG,leng_window,1)[length(poincare_variabilitys_a)],risk_poincare_variabilitys,risk2_poincare_variabilitys,time_seg(new_data$date,leng_window,1), rep("poincare_variabilitys",length(poincare_variabilitys_a)) )  
      
      cbind(seq(1,length(Max_eigen_a),by=1), Max_eigen_a,rep(ken_p(Max_eigen_a)[1],length(Max_eigen_a)), rep(ken_p(Max_eigen_a)[2],length(Max_eigen_a)), temperature_mean(TAVG,leng_window,1)[length(Max_eigen_a)],risk_Max_eigen,risk2_Max_eigen, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(Max_eigen_a))),
      cbind(seq(1,length(wavelet_filterings_a),by=1), wavelet_filterings_a,rep(ken_p(wavelet_filterings_a)[1],length(wavelet_filterings_a)), rep(ken_p(wavelet_filterings_a)[2],length(wavelet_filterings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_filterings_a)],risk_wavelet_filtering,risk2_wavelet_filterings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_filterings_a))),
      cbind(seq(1,length(wavelet_reddenings_a),by=1), wavelet_reddenings_a,rep(ken_p(wavelet_reddenings_a)[1],length(wavelet_reddenings_a)), rep(ken_p(wavelet_reddenings_a)[2],length(wavelet_reddenings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_reddenings_a)],risk_wavelet_reddening,risk2_wavelet_reddenings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_reddenings_a)))
      
    )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$length_time_series=nrow(subs_data)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$leng_window=leng_window
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=cbind("seq_length","Ews_timeSeries","tau_value","p_value","temperature",
                                    "outbreak_posit1","outbreak_posit2", #outbreak_posit1 treat the significant as 1 in risk model, while the outbreak_posit2 treat the last as 1
                                    "date1","date2",
                                    #"trend",
                                    "EWs",
                                    "ith_number","the_total",
                                    "time_length_sub","length_time_series","frequency",
                                    "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
  } # if
  
  
} # function EWs_do





## EWs over moving window, before sep-15 2024
EWs_do_TimeSeries_before_sep15_2024<-function (new_datas,leng_window,Yes_No){
  Yes_No=Yes_No
  if(Yes_No==1){ #'Yes' meaning diease may Yes or "No" outbreak
    if (length(cbind(start_end))>0) {situations<-the_outbreak;replicate_number=t2_total}
    if (length(cbind(start_end))==0) {situations<-the_outbreak;replicate_number=1}
  }
  
  if(Yes_No==0){ #'No' meaning diease "No" outbreak, by excluding the "start_end"
    situations<-'No';replicate_number=t_total}
  
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  #
  risk_model<-function(situations,lengthss,position) {
    if(situations=='No'){returns=rep(0,lengthss)}
    if(situations=='Yes'){returns=rep(0,lengthss);returns[1:(lengthss-position-1)]=0;returns[(lengthss-position):lengthss]=1} #significant point as 1 in risk model
    return(returns)
  }
  
  risk2_model<-function(situations,lengthss,position) {
    if(situations=='No'){returns=rep(0,lengthss)}
    if(situations=='Yes'){returns=rep(0,lengthss);returns[lengthss]=1} #Always the last point as 1 in risk model
    return(returns)
  }
  
  
  #
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=leng_window # difine the length of time window
    number=100 # define the number of surrogates
    
    # tau time series
    AR1_a=AR1(new_data$Incidence,leng_window,1)
    AR2_a=AR2(new_data$Incidence,leng_window,1)
    AR3_a=AR3(new_data$Incidence,leng_window,1)
    SD_a=SD(new_data$Incidence,leng_window,1)
    Skewness_a=Skewness(new_data$Incidence,leng_window,1)
    Kurtosis_a=Kurtosis(new_data$Incidence,leng_window,1)
    CV_a=CV(new_data$Incidence,leng_window,1)
    first_differenced_variance_a=first_differenced_variance(new_data$Incidence,leng_window,1)
    Autocovariance_a=Autocovariance(new_data$Incidence,leng_window,1)
    index_of_dispersion_a=index_of_dispersion(new_data$Incidence,leng_window,1)
    density_ratio_a=density_ratio(new_data$Incidence,leng_window,1)
    
    relative_dispersions_a=relative_dispersions(new_data$Incidence,leng_window,1)
    Hurst_exponents_a=Hurst_exponents(new_data$Incidence,leng_window,1)
    time_series_acceleration_a=time_series_acceleration(new_data$Incidence,leng_window,1)
    #Slopes_a=Slopes(new_data$Incidence,leng_window,1)
    no_outliers_a=no_outliers(new_data$Incidence,leng_window,1)
    #Step_changes_a=Step_changes(new_data$Incidence,leng_window,1)
    #N_peaks_a=N_peaks(new_data$Incidence,leng_window,1)
    Turning_Points_a=Turning_Points(new_data$Incidence,leng_window,1)
    #FFT_AMP_a=FFT_AMP(new_data$Incidence,leng_window,1)
    #poincare_variabilitys_a=poincare_variabilitys(new_data$Incidence,leng_window,1)
    Max_eigen_a=Max_eigen(new_data$Incidence,leng_window,1)
    wavelet_filterings_a=wavelet_filterings(new_data$Incidence,new_data$start,leng_window,1)
    wavelet_reddenings_a=wavelet_reddenings(new_data$Incidence,new_data$start,leng_window,1)
    
    # risk model
    risk_AR1=risk_model(situations,length(AR1_a),response_time(AR1_a))
    risk_AR2=risk_model(situations,length(AR2_a),response_time(AR2_a))
    risk_AR3=risk_model(situations,length(AR3_a),response_time(AR3_a))
    risk_SD=risk_model(situations,length(SD_a),response_time(SD_a))
    risk_Skewness=risk_model(situations,length(Skewness_a),response_time(Skewness_a))
    risk_Kurtosis=risk_model(situations,length(Kurtosis_a),response_time(Kurtosis_a))
    risk_CV=risk_model(situations,length(CV_a),response_time(CV_a))
    risk_first_differenced_variance=risk_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a))
    risk_Autocovariance=risk_model(situations,length(Autocovariance_a),response_time(Autocovariance_a))
    risk_index_of_dispersion=risk_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a))
    risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a))
    risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a))
    risk_density_ratio=risk_model(situations,length(density_ratio_a),response_time(density_ratio_a))
    
    risk_relative_dispersions=risk_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a))
    risk_Hurst_exponents=risk_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a))
    risk_time_series_acceleration=risk_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a))
    #risk_Slopes=risk_model(situations,length(Slopes_a),response_time(Slopes_a))
    risk_no_outliers=risk_model(situations,length(no_outliers_a),response_time(no_outliers_a))
    #risk_Step_changes=risk_model(situations,length(Step_changes_a),response_time(Step_changes_a))
    #risk_N_peaks=risk_model(situations,length(N_peaks_a),response_time(N_peaks_a))
    risk_Turning_Points=risk_model(situations,length(Turning_Points_a),response_time(Turning_Points_a))
    #risk_FFT_AMP=risk_model(situations,length(FFT_AMP_a),response_time(FFT_AMP_a))
    #risk_poincare_variabilitys=risk_model(situations,length(poincare_variabilitys_a),response_time(poincare_variabilitys_a))
    risk_Max_eigen=risk_model(situations,length(Max_eigen_a),response_time(Max_eigen_a))
    risk_wavelet_filtering=risk_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a))
    risk_wavelet_reddening=risk_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a))
    
    # risk model2
    risk2_AR1=risk2_model(situations,length(AR1_a),response_time(AR1_a))
    risk2_AR2=risk2_model(situations,length(AR2_a),response_time(AR2_a))
    risk2_AR3=risk2_model(situations,length(AR3_a),response_time(AR3_a))
    risk2_SD=risk2_model(situations,length(SD_a),response_time(SD_a))
    risk2_Skewness=risk2_model(situations,length(Skewness_a),response_time(Skewness_a))
    risk2_Kurtosis=risk2_model(situations,length(Kurtosis_a),response_time(Kurtosis_a))
    risk2_CV=risk2_model(situations,length(CV_a),response_time(CV_a))
    risk2_first_differenced_variance=risk2_model(situations,length(first_differenced_variance_a),response_time(first_differenced_variance_a))
    risk2_Autocovariance=risk2_model(situations,length(Autocovariance_a),response_time(Autocovariance_a))
    risk2_index_of_dispersion=risk2_model(situations,length(index_of_dispersion_a),response_time(index_of_dispersion_a))
    risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a))
    risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a))
    risk2_density_ratio=risk2_model(situations,length(density_ratio_a),response_time(density_ratio_a))
    
    risk2_relative_dispersions=risk2_model(situations,length(relative_dispersions_a),response_time(relative_dispersions_a))
    risk2_Hurst_exponents=risk2_model(situations,length(Hurst_exponents_a),response_time(Hurst_exponents_a))
    risk2_time_series_acceleration=risk2_model(situations,length(time_series_acceleration_a),response_time(time_series_acceleration_a))
    #risk2_Slopes=risk2_model(situations,length(Slopes_a),response_time(Slopes_a))
    risk2_no_outliers=risk2_model(situations,length(no_outliers_a),response_time(no_outliers_a))
    # risk2_Step_changes=risk2_model(situations,length(Step_changes_a),response_time(Step_changes_a))
    #risk2_N_peaks=risk2_model(situations,length(N_peaks_a),response_time(N_peaks_a))
    risk2_Turning_Points=risk2_model(situations,length(Turning_Points_a),response_time(Turning_Points_a))
    #risk2_FFT_AMP=risk2_model(situations,length(FFT_AMP_a),response_time(FFT_AMP_a))
    #risk2_poincare_variabilitys=risk2_model(situations,length(poincare_variabilitys_a),response_time(poincare_variabilitys_a))
    risk2_Max_eigen=risk2_model(situations,length(Max_eigen_a),response_time(Max_eigen_a))
    risk2_wavelet_filterings=risk2_model(situations,length(wavelet_filterings_a),response_time(wavelet_filterings_a))
    risk2_wavelet_reddenings=risk2_model(situations,length(wavelet_reddenings_a),response_time(wavelet_reddenings_a))
    
    
    final_results_2=rbind(
      cbind(AR1_a,rep(ken_p(AR1_a)[1],length(AR1_a)), rep(ken_p(AR1_a)[2],length(AR1_a)), temperature_mean(TAVG,leng_window,1)[length(AR1_a)],risk_AR1,risk2_AR1, time_seg(new_data$date,leng_window,1), rep("AR1",length(AR1_a))),
      cbind(AR2_a,rep(ken_p(AR2_a)[1],length(AR2_a)), rep(ken_p(AR2_a)[2],length(AR2_a)), temperature_mean(TAVG,leng_window,1)[length(AR2_a)],risk_AR2,risk2_AR2, time_seg(new_data$date,leng_window,1),rep("AR2",length(AR2_a))),
      cbind(AR3_a,rep(ken_p(AR3_a)[1],length(AR3_a)), rep(ken_p(AR3_a)[2],length(AR3_a)), temperature_mean(TAVG,leng_window,1)[length(AR3_a)],risk_AR3,risk2_AR3,time_seg(new_data$date,leng_window,1), rep("AR3",length(AR3_a))),
      cbind(SD_a,rep(ken_p(SD_a)[1],length(SD_a)), rep(ken_p(SD_a)[2],length(SD_a)), temperature_mean(TAVG,leng_window,1)[length(SD_a)],risk_SD,risk2_SD,time_seg(new_data$date,leng_window,1), rep("SD",length(SD_a))),
      cbind(Skewness_a,rep(ken_p(Skewness_a)[1],length(Skewness_a)), rep(ken_p(Skewness_a)[2],length(Skewness_a)), temperature_mean(TAVG,leng_window,1)[length(Skewness_a)],risk_Skewness,risk2_Skewness,time_seg(new_data$date,leng_window,1), rep("Skewness",length(Skewness_a))),
      cbind(Kurtosis_a,rep(ken_p(Kurtosis_a)[1],length(Kurtosis_a)), rep(ken_p(Kurtosis_a)[2],length(Kurtosis_a)), temperature_mean(TAVG,leng_window,1)[length(Kurtosis_a)],risk_Kurtosis,risk2_Kurtosis,time_seg(new_data$date,leng_window,1), rep("Kurtosis",length(Kurtosis_a))),
      cbind(CV_a,rep(ken_p(CV_a)[1],length(CV_a)), rep(ken_p(CV_a)[2],length(CV_a)), temperature_mean(TAVG,leng_window,1)[length(CV_a)],risk_CV,risk2_CV,time_seg(new_data$date,leng_window,1), rep("CV",length(CV_a))),
      cbind(first_differenced_variance_a,rep(ken_p(first_differenced_variance_a)[1],length(first_differenced_variance_a)), rep(ken_p(first_differenced_variance_a)[2],length(first_differenced_variance_a)), temperature_mean(TAVG,leng_window,1)[length(first_differenced_variance_a)],risk_first_differenced_variance,risk2_first_differenced_variance,time_seg(new_data$date,leng_window,1), rep("first_differenced_variance",length(first_differenced_variance_a))),
      cbind(Autocovariance_a,rep(ken_p(Autocovariance_a)[1],length(Autocovariance_a)), rep(ken_p(Autocovariance_a)[2],length(Autocovariance_a)), temperature_mean(TAVG,leng_window,1)[length(Autocovariance_a)],risk_Autocovariance,risk2_Autocovariance,time_seg(new_data$date,leng_window,1), rep("Autocovariance",length(Autocovariance_a))),
      cbind(index_of_dispersion_a,rep(ken_p(index_of_dispersion_a)[1],length(index_of_dispersion_a)), rep(ken_p(index_of_dispersion_a)[2],length(index_of_dispersion_a)), temperature_mean(TAVG,leng_window,1)[length(index_of_dispersion_a)],risk_index_of_dispersion,risk2_index_of_dispersion,time_seg(new_data$date,leng_window,1), rep("index_of_dispersion",length(index_of_dispersion_a))),
      cbind(density_ratio_a,rep(ken_p(density_ratio_a)[1],length(density_ratio_a)), rep(ken_p(density_ratio_a)[2],length(density_ratio_a)), temperature_mean(TAVG,leng_window,1)[length(density_ratio_a)],risk_density_ratio,risk2_density_ratio,time_seg(new_data$date,leng_window,1), rep("density_ratio",length(density_ratio_a))),
      #cbind(Max_eigen_a,temperature_mean(TAVG,leng_window,1)[length(AR2_a)],rep("Max_eigen",length(Max_eigen_a))),
      #vest function
      cbind(relative_dispersions_a[!(is.infinite(relative_dispersions_a))],rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[1],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), rep(ken_p(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])[2],length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))])), 
            temperature_mean(TAVG[1:nrow(new_data)],leng_window,1)[!(is.infinite(relative_dispersions_a))], 
            risk_relative_dispersions[!(is.infinite(relative_dispersions_a))],
            risk2_relative_dispersions[!(is.infinite(relative_dispersions_a))],
            time_seg(new_data$date,leng_window,1)[!(is.infinite(relative_dispersions_a)),],
            rep("relative_dispersions",length(relative_dispersions_a[!(is.infinite(relative_dispersions_a))]))),
      #cbind(max_lyapunov_exps_a,"max_lyapunov_exps",length(max_lyapunov_exps_a))),
      cbind(Hurst_exponents_a,rep(ken_p(Hurst_exponents_a)[1],length(Hurst_exponents_a)), rep(ken_p(Hurst_exponents_a)[2],length(Hurst_exponents_a)), temperature_mean(TAVG,leng_window,1)[length(Hurst_exponents_a)],risk_Hurst_exponents,risk2_Hurst_exponents,time_seg(new_data$date,leng_window,1), rep("Hurst_exponents",length(Hurst_exponents_a))),
      cbind(time_series_acceleration_a,rep(ken_p(time_series_acceleration_a)[1],length(time_series_acceleration_a)), rep(ken_p(time_series_acceleration_a)[2],length(time_series_acceleration_a)), 
            temperature_mean(TAVG,leng_window,1)[length(time_series_acceleration_a)],
            risk_time_series_acceleration,
            risk2_time_series_acceleration,
            time_seg(new_data$date,leng_window,1), 
            rep("time_series_acceleration",length(time_series_acceleration_a))),
      #cbind(Slopes_a,rep(ken_p(Slopes_a)[1],length(Slopes_a)), rep(ken_p(Slopes_a)[2],length(Slopes_a)), temperature_mean(TAVG,leng_window,1)[length(Slopes_a)],risk_Slopes,risk2_Slopes,time_seg(new_data$date,leng_window,1), rep("Slopes",length(Slopes_a))),
      #cbind(Daubechies_DWT_a,temperature_mean(TAVG,leng_window,1)[length(Daubechies_DWT_a)],risk_AR1, rep("Daubechies_DWT",length(Daubechies_DWT_a))),
      cbind(no_outliers_a,rep(ken_p(no_outliers_a)[1],length(no_outliers_a)), rep(ken_p(no_outliers_a)[2],length(no_outliers_a)), temperature_mean(TAVG,leng_window,1)[length(no_outliers_a)],risk_no_outliers,risk2_no_outliers,time_seg(new_data$date,leng_window,1), rep("no_outliers",length(no_outliers_a))),
      #cbind(Step_changes_a,rep(ken_p(Step_changes_a)[1],length(Step_changes_a)), rep(ken_p(Step_changes_a)[2],length(Step_changes_a)), temperature_mean(TAVG,leng_window,1)[length(Step_changes_a)],risk_Step_changes,risk2_Step_changes,time_seg(new_data$date,leng_window,1), rep("Step_changes",length(Step_changes_a))),
      #cbind(N_peaks_a,rep(ken_p(N_peaks_a)[1],length(N_peaks_a)), rep(ken_p(N_peaks_a)[2],length(N_peaks_a)), temperature_mean(TAVG,leng_window,1)[length(N_peaks_a)],risk_N_peaks,risk2_N_peaks,time_seg(new_data$date,leng_window,1), rep("N_peaks",length(N_peaks_a))),
      cbind(Turning_Points_a,rep(ken_p(Turning_Points_a)[1],length(Turning_Points_a)), rep(ken_p(Turning_Points_a)[2],length(Turning_Points_a)), temperature_mean(TAVG,leng_window,1)[length(Turning_Points_a)],risk_Turning_Points,risk2_Turning_Points,time_seg(new_data$date,leng_window,1), rep("Turning_Points",length(Turning_Points_a))),
      #cbind(FFT_AMP_a,rep(ken_p(FFT_AMP_a)[1],length(FFT_AMP_a)), rep(ken_p(FFT_AMP_a)[2],length(FFT_AMP_a)), temperature_mean(TAVG,leng_window,1)[length(FFT_AMP_a)],risk_FFT_AMP,risk2_FFT_AMP, time_seg(new_data$date,leng_window,1),rep("FFT_AMP",length(FFT_AMP_a))),
      #cbind(poincare_variabilitys_a,rep(ken_p(poincare_variabilitys_a)[1],length(poincare_variabilitys_a)), rep(ken_p(poincare_variabilitys_a)[2],length(poincare_variabilitys_a)), temperature_mean(TAVG,leng_window,1)[length(poincare_variabilitys_a)],risk_poincare_variabilitys,risk2_poincare_variabilitys,time_seg(new_data$date,leng_window,1), rep("poincare_variabilitys",length(poincare_variabilitys_a)) )  
      
      cbind(Max_eigen_a,rep(ken_p(Max_eigen_a)[1],length(Max_eigen_a)), rep(ken_p(Max_eigen_a)[2],length(Max_eigen_a)), temperature_mean(TAVG,leng_window,1)[length(Max_eigen_a)],risk_Max_eigen,risk2_Max_eigen, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(Max_eigen_a))),
      cbind(wavelet_filterings_a,rep(ken_p(wavelet_filterings_a)[1],length(wavelet_filterings_a)), rep(ken_p(wavelet_filterings_a)[2],length(wavelet_filterings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_filterings_a)],risk_wavelet_filtering,risk2_wavelet_filterings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_filterings_a))),
      cbind(wavelet_reddenings_a,rep(ken_p(wavelet_reddenings_a)[1],length(wavelet_reddenings_a)), rep(ken_p(wavelet_reddenings_a)[2],length(wavelet_reddenings_a)), temperature_mean(TAVG,leng_window,1)[length(wavelet_reddenings_a)],risk_wavelet_reddening,risk2_wavelet_reddenings, time_seg(new_data$date,leng_window,1), rep("Max_eigen",length(wavelet_reddenings_a)))

      )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=replicate_number
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=situations
    final_results_2$number=1
    final_results_2$leng_window=leng_window
    final_results_2$Yes_No=Yes_No
    colnames(final_results_2)=cbind("Ews_timeSeries","tau_value","p_value","temperature",
                                    "outbreak_posit1","outbreak_posit2", #outbreak_posit1 treat the significant as 1 in risk model, while the outbreak_posit2 treat the last as 1
                                    "date1","date2",
                                    #"trend",
                                    "EWs",
                                    "ith_number","the_total",
                                    "time_length",
                                    "frequency",
                                    "disease","country_region","outbreaks","number","leng_window","Yes_No") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
  } # if
  
  
} # function EWs_do
